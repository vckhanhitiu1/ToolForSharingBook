import {Component} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {MapComponent} from './components/map.component';
import {OcrComponent} from './components/ocr.component';
import {HomeComponent} from './components/home.component';
import {BookRegistrationComponent} from './components/bookregistration.component';
import {MemberRegitrationFormComponent} from './components/memberregistration.component';
import {NotFoundComponent} from './components/notfound.component';
import {LoginComponent} from './components/login/login.component';
import {RegisterComponent} from './components/register/register.component';
import {AuthGuard} from './services/auth.guard.service'
@Component({
  selector: 'fountain-root'
})
export class RootComponent {}

export const routes: Routes = [

  {
    path: '',
    component: HomeComponent
  },
  {
  path:'login',
  component: LoginComponent
},
{
  path:'register',
  component:RegisterComponent
},

{
  path:'map',
  component:MapComponent
},
{
  path:'bookregistration',
  component: BookRegistrationComponent,
  canLoad: [AuthGuard]

},
{
  path: 'memberregistration',
  component:MemberRegitrationFormComponent,
  canLoad: [AuthGuard]

},
{
  path: '**',
  component: NotFoundComponent
}
];

export const routing = RouterModule.forRoot(routes);
