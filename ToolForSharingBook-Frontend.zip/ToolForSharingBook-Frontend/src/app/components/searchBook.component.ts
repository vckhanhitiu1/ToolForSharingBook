/**
 * Created by Vo on 6/11/2017.
 */
import {Component, Input} from "@angular/core";
import {SearchService} from "../services/search.service";
import {error} from "util";
@Component({
  selector:'search-book',
  template:`
    <div class="col-lg-10">
      <input type="text" [(ngModel)]="keyword" name="keyword"/>
      <button (click)="Search()" )>Search</button>
    </div>
  `

})
export class SearchBookComponent
{

  @Input() books:any[];
  public keyword:String;
  constructor(private searchService:SearchService)
  {
  }
  Search()
  {
    this.searchService.Search(this.keyword).subscribe(
      (response:any) =>{
        this.books=response;
        console.log(response);
      },
      error=>{
        console.log(error);
      }
    )
  }
}
