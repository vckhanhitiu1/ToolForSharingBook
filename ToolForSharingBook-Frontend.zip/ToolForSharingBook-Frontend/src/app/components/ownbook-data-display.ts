/**
 * Created by Vo on 6/1/2017.
 */
import {Component, EventEmitter, Input, Output} from "@angular/core";
import {Member} from "../models/data/Member.model";
import {OwnBookDataDisplayOption, OwnBookToolbarDisplayOptions} from "../services/resources.service";
import {Action} from "../models/data/toolbar-action";
import { MemberService } from "../services/member.service";

@Component({
  selector:'ownbook-data-display',
  template:`
  
  <div class="card border-infor-window ownbook-data-display-card">
    <div class ="card-header ownbook-data-display-header background-axon">
    <member-basic-display class="col-8 pr-0"
     [member]="member">
    </member-basic-display>
      <ownbook-toolbar-display  class="col-4 pt-1 text-right ownBooks-toolbar-display-container"
      [displayOption]="ownBookDataDisplayOption?.ownBookToolbarDisplayOption"
                               (onActionDispatch)="forwardActions($event)">
      </ownbook-toolbar-display>

    </div>
     <book-info
     [member]="member">
     </book-info>   
  </div>
  `
})
export class OwnBookDataDisplay
{
  @Input() member: Member;
  @Input() ownBookDataDisplayOption: OwnBookDataDisplayOption;
  @Output() onActionDispatch = new EventEmitter();


   private forwardActions(action: Action) {
        this.onActionDispatch.emit(action);
    }
   

}
