/**
 * Created by Vo on 6/6/2017.
 */
import {Component, Input, OnInit} from "@angular/core";
import {Login} from "../../models/data/login.model";
import {LogInService} from "../../services/login.service";
import {RegisterService} from "../../services/register.service";
import {Router} from "@angular/router";
import {AlertService} from '../../services/alert.service';

@Component({
  selector:'register',
  template:`
    <h2>Regist New Account</h2>
    <form #registerForm="ngForm" (ngSubmit)="registerForm.form.valid && AddNewAccount() " novalidate>
      <div class="form-group" [ngClass]="{'has-error':registerForm.submitted && !username.valid}">
        <label>User Name</label>
        <input type="text" class="form-control" name="username" required #username [(ngModel)]="login.username">
        <div *ngIf="registerForm.submitted && !username.valid" class="help-block">Username is required</div>
      </div>
      <div class="form-group" [ngClass]="{'has-error':registerForm.submitted && !password.valid}">
        <label>PassWord</label>
        <input type="password" class="form-control" name="password" required #password [(ngModel)]="login.password">
        <div *ngIf="registerForm.submitted && !password.valid" class="help-block">Password is required</div>
      </div>
      <div class="form-group" [ngClass]="{'has-error':registerForm.submitted && !passwordConfirm.valid}">
        <label>PassWord Confirm</label>
        <input type="password" class="form-control" name="passwordConfirm" required #passwordConfirm [(ngModel)]="login.passwordConfirm">
        <div *ngIf="registerForm.submitted && !passwordConfirm.valid" class="help-block">Confirm Password is required</div>
      </div>
      <div class="form-group" [ngClass]="{'has-error':registerForm.submitted && !passwordConfirm.valid}">
        <label>Email</label>
        <input type="email" class="form-control" name="email" required #email [(ngModel)]="login.email">
        <div *ngIf="registerForm.submitted && !passwordConfirm.valid" class="help-block">Confirm Password is required</div>
      </div>
      <tr>
        <td>
          <button type="submit" class="btn btn-success">Save</button>
          <a [routerLink]="['/login']" class="btn btn-link">Cancel</a>
        </td>
      </tr>
    </form>

  `,
  providers: [RegisterService,AlertService]

    // require('./regiter.component.html')
})
export class RegisterComponent implements OnInit
{
  @Input() login:any;
  loading:boolean = false;
  constructor(private registerService: RegisterService, private router:Router,private alertService:AlertService)
  {
  }
  ngOnInit()
  {
    this.login = {};
  }

  AddNewAccount()
  {
    this.registerService.PostNewAccount(this.login).subscribe(
      response=>{
        if(response)
        {
          alert("Creat success");
          this.router.navigate(['/login'])
        }
        else {
          error => {
            this.alertService.error(error);
            this.loading = false;
          }
        }
      });


}

}
