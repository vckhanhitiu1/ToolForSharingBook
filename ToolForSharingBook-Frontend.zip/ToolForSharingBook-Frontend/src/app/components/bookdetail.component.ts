import {Component} from '@angular/core';

@Component({
	selector:'book-detail',
	template:`
  <div>
    
  </div>
  `


})
export class BookDetailComponent{
}
