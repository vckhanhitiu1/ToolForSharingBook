import {Component, Input, OnInit} from "@angular/core";
import {Login} from "../../models/data/login.model";
import {AuthenticationService} from "../../services/authentication.service";
import {ActivatedRoute, Router,NavigationExtras} from "@angular/router";
import {AlertService} from '../../services/alert.service';
import {LogInService} from "../../services/login.service";
import { Http } from '@angular/http';
import { contentHeaders } from '../../technical/headers';
@Component({
	selector:"log-in",
	template:
  `
  <div class="login jumbotron center-block">
  <h1>Login</h1>
  <p>{{message}}</p>

  <form #loginForm="ngForm" (ngSubmit)="CheckLogIn(loginForm.value)">
  <div class="form-group">
    <label for="username">Username</label>
          <input type="text" class="form-control" name="username" placeholder="Enter your username" #username ngModel required>
  </div>
  <div class="form-group">
    <label for="password">Password</label>
          <input type="password" class="form-control" password="password"  name="password" placeholder="Enter your password" #password  ngModel required>
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
    <a [routerLink]="['/register']">Click here to Signup</a>
    <button (click)="logout()" *ngIf="loginservice.isLoggedIn">Logout</button>

</form>
</div>
  `
  // require('./login.component.html')
})
export class LoginComponent implements OnInit
{
	 private logins: Login[];

  message: string;

   constructor(public router: Router, public http: Http, private authenticationservice:AuthenticationService, private loginservice:LogInService) {
     this.setMessage();
}

setMessage()
{
      this.message = 'Logged ' + (this.loginservice.isLoggedIn ? 'in' : 'out');
}

ngOnInit()
{
  this.loginservice.GetAccount().subscribe((login:Login[])=>{
    this.logins=login
    console.log(login);
  })
}

CheckLogIn(value:any)
{
  console.log(value);
  for(let login of this.logins)
  {
    if(value.username==login.username && value.password==login.password)
    {
      this.login();
    }
  } 
  // this.onLoginSubmit(value);

}

login() {
    this.message = 'Trying to log in ...';

    this.loginservice.login().subscribe(() => {
      this.setMessage();
      if (this.loginservice.isLoggedIn) {
        // Get the redirect URL from our auth service
        // If no redirect has been set, use the default
        let redirect = this.loginservice.redirectUrl ? this.loginservice.redirectUrl : '/bookregistration';

        // Set our navigation extras object
        // that passes on our global query params and fragment
        // let navigationExtras: NavigationExtras = {
        //   preserveQueryParams: true,
        //   preserveFragment: true
        // };

        // Redirect the user
        this.router.navigate([redirect]);
      }
    });
  }


// onLoginSubmit(loginvalue:any) {
//     this.authenticationservice.login(loginvalue)
//       .map(res => res.json())
//       .subscribe(
//         response => this.authenticationservice.finishAuthentication(response.token));
//   }
 logout() {
    this.loginservice.logout();
    this.setMessage();
  }

}
