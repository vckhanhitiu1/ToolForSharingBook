import {Component,Input, OnInit, ElementRef, AfterViewInit} from '@angular/core';
import {RouterModule, Routes, Router} from '@angular/router';
import {MemberService} from '../services/member.service';
import {PlacesAutoCompleteService} from "../services/places-auto-complete.service";
import {GoogleMapsGeocodingService} from "../services/google-maps-geocoding.service";
import {Member} from "../models/data/Member.model";
import {Address} from "../models/data/Address.model";
import {GPSLocation} from "../models/data/GPSLocation.model";
import {AUTO_COMPLETE_INPUT,GPS_INPUT,GPS_LAT_INPUT,GPS_LNG_INPUT} from "../constant/sharing-book-element.constant";
@Component({
  selector: 'member-registration-form',
  template:require("../template/member-form.html"),
  providers:[MemberService, PlacesAutoCompleteService,GoogleMapsGeocodingService]

})
export class MemberRegitrationFormComponent implements OnInit
{
  @Input()  member: any;

  // private tempMember : Member;
  private autoCompleteAddress: string;
  private isAddressInputValid:boolean = true;
  private noAddressFound : boolean =false;
  private autoCompleteElementID: string = AUTO_COMPLETE_INPUT;

   constructor(private memberService:MemberService,  private router:Router,
     private placesAutoCompleteService: PlacesAutoCompleteService,
     private geocodingService: GoogleMapsGeocodingService,
     private el:ElementRef) {}

  ngOnInit()
  {
   
   this.member ={}; 

    if(this.member!=null && this.member.address!=null)
      this.autoCompleteAddress = this.member.address.toString();
   
    this.placesAutoCompleteService.observableAddress$.subscribe(data=>
      {
        if(data!=null)
        {
          this.isAddressInputValid=true;
          this.member.address= new Address(data);
        }
      }
    );
    this.placesAutoCompleteService.observableStatus$.subscribe(status=>{
      if(status == google.maps.places.PlacesServiceStatus.ZERO_RESULTS)
      {
        this.noAddressFound= true;

      }
      if (status == google.maps.places.PlacesServiceStatus.OK) {
        this.noAddressFound = false;
      }
    });
    this.geocodingService.observableGPS$.subscribe(gps => {
      if (gps != null) {
        console.log(gps);
        this.member.address.gpsLocation = new GPSLocation(gps.latitude, gps.longtitude);
      }
    });
    this.placesAutoCompleteService.turnOnSuggestion(this.autoCompleteElementID);
  }


     GotoMemberInformation()
  {
    this.router.navigate(['/memberregistration']);
  }

  SaveForm() {
      if(this.member.address.isValid() && this.member.address!=null){
      this.memberService.PostMember(this.member).subscribe(response => {
        if (response) {
          alert('Add Success');
          this.router.navigate(['/memberregistration']);
        }
        // else{
        //   alert('Can not Save');
        //   this.router.navigate(['/memberregistration']);
        // }
      });
    }
    else{
      this.isAddressInputValid=false;
    }
  }

  public turnOnAutoComplete()
  {
    this.placesAutoCompleteService.turnOnSuggestion(this.autoCompleteElementID);
  }
  private followPredictionStatus(event: any) {
    if (event.target.value != '' && event.target.value != null) {
      this.placesAutoCompleteService.turnOnStatusSubscriptions(this.autoCompleteElementID, event.target.value);
    }
  }

}
