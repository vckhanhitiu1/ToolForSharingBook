/**
 * Created by Vo on 2/22/2017.
 */
import {Component, ViewChild, Output, EventEmitter} from "@angular/core";
import {fx} from "glfx";

@Component({
  selector: 'home',
  template:`
    <h1>Welcome</h1>
  `,

})
export class HomeComponent
{
  constructor(){
  }
}
