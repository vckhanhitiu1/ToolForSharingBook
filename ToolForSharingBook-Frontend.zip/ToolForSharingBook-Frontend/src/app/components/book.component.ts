import {Input,OnInit,Component} from "@angular/core";
import {RouterModule, Routes, Router} from '@angular/router';
import { DomSanitizer} from '@angular/platform-browser';
import { Pipe } from '@angular/core';
/**
 * Created by Vo on 2/19/2017.
 */
import {BookService} from '../services/book.service';
import {Authors} from '../models/data/Author.model';
import {Book} from '../models/data/Book.model';
@Component({
  selector:'book-list',
  template: `

<h1>Book information</h1>
<table>
<thead>
<tr>
<td>Title</td>
<td>Description</td>
<td>ISBN</td>
<td>Book Type</td>
<td>Book Status</td>
<td>Authors</td>
<td>Image</td>
</tr>
</thead>
<tbody>
<tr *ngFor="let book of books">
<td>{{book.bookname}}</td>
<td>{{book.description}}</td>
<td>{{book.isbn}}</td>
<td>{{book.booktype}}</td>
<td>{{book.status}}</td>
<td>{{book.authors}}</td>
<td>
<span class="thumbnail"><img src = "data:image\jpeg;base64,{{book.image}}" height="150px" width="150px" />
</span></td>
</tr>
</tbody>
</table>
`,
providers:[BookService]
})

@Pipe({name: 'safeHtml'})
export class BookComponent implements OnInit
{
  public books: Book[];
  
  constructor(private bookservice:BookService,  private router:Router,private sanitizer:DomSanitizer) {
  }

  transform(html) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(html);
  }

  ngOnInit()
  {
    this.bookservice.GetListBook().subscribe(
      (book:Book[])=>{this.books=book}
    );
  }
  GotoBooKInformation()
  {
    this.router.navigate(['/bookregistration']);
  }
}
