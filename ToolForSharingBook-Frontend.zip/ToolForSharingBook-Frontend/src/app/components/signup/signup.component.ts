import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Http } from '@angular/http';
import { contentHeaders } from '../../technical/headers';
@Component({
  selector: 'signup',
  template: 
  `
  <div class="signup center-block jumbotron">
  <h1>Signup</h1>
  <form role="form" (submit)="signup($event, username.value, password.value)">
  <div class="form-group">
    <label for="username">Username</label>
    <input type="text" #username class="form-control" id="username" placeholder="Username">
  </div>
  <div class="form-group">
    <label for="password">Password</label>
    <input type="password" #password class="form-control" id="password" placeholder="Password">
  </div>
  <div class="form-group">
    <label for="Confirm password">Password</label>
    <input type="password" #confirmpassword class="form-control" id="confirmpassword" placeholder="Confirm Password">
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
</form>
</div>
  `
})
export class Signup {
  constructor(public router: Router, public http: Http) {
  }

  signup(event, username, password) {
    event.preventDefault();
    let body = JSON.stringify({ username, password });
    this.http.post('http://localhost:3001/users', body, { headers: contentHeaders })
      .subscribe(
        response => {
          localStorage.setItem('id_token', response.json().id_token);
          this.router.navigate(['home']);
        },
        error => {
          alert(error.text());
          console.log(error.text());
        }
      );
  }

  login(event) {
    event.preventDefault();
    this.router.navigate(['login']);
  }

}