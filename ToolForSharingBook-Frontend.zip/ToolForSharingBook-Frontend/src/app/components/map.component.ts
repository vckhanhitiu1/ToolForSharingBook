import {Component, EventEmitter, Input, Output} from '@angular/core';
import {GPSLocation} from '../models/data/GPSLocation.model';
import {Member} from '../models/data/Member.model';
import {GOOGLE_MAP} from '../constant/app.constants';
import { SebmGoogleMap, SebmGoogleMapMarker, AgmCoreModule} from 'angular2-google-maps/core';
import {MemberService} from '../services/member.service';
import {Action} from "../models/data/toolbar-action";
import {MapDisplayOption, OwnBookDataDisplayOption} from "../services/resources.service";

@Component({
  selector:'generate-map',
  template:`    
    <ownbook-data-display
      *ngIf="showMemberSelectedDisplay && !ownBookDisplayOption.memberEditMode"
      [member]="selectedMember" 
      [ownBookDataDisplayOption]="ownBookDataDisplayOption" 
      (onActionDispatch)="forwardActions($event)" 
    ></ownbook-data-display>
  <sebm-google-map 
      [latitude]="currentLocation.latitude" 
        [longitude]="currentLocation.longitude" 
      [zoom]="zoom_level"
      [streetViewControl]="false"
      (mapClick)="deselectedMarker()"> 
  <member-marker-display 
    [members]="members"
    (onMarkerClick)="memberSelected($event)">
  </member-marker-display>
  </sebm-google-map> 
`,
providers: [MemberService]
})
export class MapComponent
{

  @Input() members:Member[]
  private currentLocation=GOOGLE_MAP.HCM_LOCATION;
  private zoom_level = GOOGLE_MAP.DEFAULT_ZOOM_LEVEL;

  @Input() ownBookDataDisplayOption: OwnBookDataDisplayOption;
  @Input() ownBookDisplayOption: MapDisplayOption;
  private selectedMember: Member;
  private showMemberSelectedDisplay:boolean;

  @Output() onActionDispatch = new EventEmitter();

   constructor(private memberservice: MemberService) {
     this.loadCurrentLocation();
  }
  
 private loadCurrentLocation() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(this.setCurrentLocation.bind(this), this.setDefaultLocation.bind(this));
      }
      else
      {
          this.setDefaultLocation();
      }
 }

 private memberSelected(member:Member)
{
  this.showMemberSelectedDisplay= true;
  this.selectedMember=member;
}
private deselectedMarker()
{
  if(!this.ownBookDisplayOption.memberEditMode)
    this.showMemberSelectedDisplay=false;
}

private forwardActions(action:Action)
{
  this.onActionDispatch.emit(action);
}

  private setCurrentLocation(location)
  {
    this.currentLocation.latitude= location.coords.latitude;
    this.currentLocation.longitude= location.coords.longitude;
  }
 private setDefaultLocation() {
        this.currentLocation = GOOGLE_MAP.HCM_LOCATION;
    }
}





