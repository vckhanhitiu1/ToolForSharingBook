/**
 * Created by Vo on 2/22/2017.
 */

import {Component, ElementRef, ViewChild, AfterViewInit} from '@angular/core';

@Component({
  selector:'ocr-app',
  template:
  `    

  `
})
export class OcrComponent
{


}
