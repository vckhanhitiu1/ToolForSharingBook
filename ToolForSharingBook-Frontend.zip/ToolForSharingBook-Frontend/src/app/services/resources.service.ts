import {Injectable, Injector} from "@angular/core";
import {APP_OPTIONS} from "../constant/app.constants";
import GenericService from "./generic.service";
/**
 * Created by Vo on 6/1/2017.
 */


export  interface  AppOptions
{
  mapDisplayOption: MapDisplayOption,
  ownBookDataDisplayOption: OwnBookDataDisplayOption
}

export interface OwnBookToolbarDisplayOptions
{
  hideEditButton: Boolean;
  hideSwitchModeButton: Boolean;
  expandMode: Boolean;
}

export interface OwnBookDataDisplayOption
{
  ownBookToolbarDisplayOption:OwnBookToolbarDisplayOptions;
}

export  interface MapDisplayOption
{
  showAllMember: boolean,
  memberEditMode:boolean
}

@Injectable()
export class ResourceService extends  GenericService
{

  constructor(injector: Injector) {
    super(injector);
  }

  private appOptions: AppOptions = APP_OPTIONS;
  public getAppOption(): AppOptions
{
  return this.appOptions;
}

}
