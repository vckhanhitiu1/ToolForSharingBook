import GenericService from "./generic.service";
import {Member} from "../models/data/Member.model";
import {Injectable, Injector} from "@angular/core";
import {Http, Response} from "@angular/http";
import {Observable} from "rxjs/Observable";
import "rxjs/add/operator/map"
/**
 * Created by Vo on 2/19/2017.
 */

@Injectable()
export class MemberService extends GenericService
{
  private members: Array<Member>;

  constructor(injector:Injector, public _http:Http) {
    super(injector)
    this.BASE_URL +='members';
  }

  public getMemberWithDisplayMode(showAll?: boolean): Observable<Member[]>
  {
    if(showAll === true)
    return this.GetListMember();
  }

  GetListMember():Observable<Member[]>{
    return this.get();
  }

  PostMember(member:Member): Observable<Response>
  {
  	return this.post(member);
  }

  PutMember(member:Member): Observable<Response>
  {
    return this.put(member);
  }

}
