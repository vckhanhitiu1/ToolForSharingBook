import {Injectable} from "@angular/core";
import {MapsAPILoader} from "angular2-google-maps/core";
import {GPSLocation} from "../models/data/GPSLocation.model";
import {Address} from "../models/data/Address.model";
import GeocoderResult = google.maps.GeocoderResult;
import GeocoderStatus = google.maps.GeocoderStatus;
import PlaceResult = google.maps.places.PlaceResult;
import {Subject} from "rxjs";

@Injectable()
export class GoogleMapsGeocodingService {

    private geocoder;
    private addresses = new Subject<Address>();
    private gps = new Subject<GPSLocation>();
    observableAddress$ = this.addresses.asObservable();
    observableGPS$ = this.gps.asObservable();

    constructor(private apiLoader: MapsAPILoader) {
        this.apiLoader.load().then(() => {
            this.geocoder = new google.maps.Geocoder();
        })
    }

    public extractGPSFromAddress(address: string) {
        if (this.geocoder) {
            this.geocoder.geocode({'address': address}, (results: GeocoderResult[]) => {
                if (results != null) {
                    let firstResult = results[0];
                    if (firstResult != null) {
                        if (firstResult.geometry != null) {
                            this.gps.next(new GPSLocation(firstResult.geometry.location.lat(), firstResult.geometry.location.lng()));
                        }
                    }
                }
            });
        }
    } 

    public saveAddressObjectFromAddressString(addressString: string) {
        if (this.geocoder) {
            this.geocoder.geocode({'address': addressString}, (results: GeocoderResult[]) => {
                if (results !== null) {
                    let firstResult = results[0];
                    console.log('first geocoder result: ', firstResult);
                    if (firstResult !== null)
                        this.addresses.next(this.convertPlaceResultToAddressObject(firstResult.address_components, firstResult.geometry));
                }
            });
        }
    }

    public saveAddressObjectFromGPS(gpsLocation: GPSLocation) {
        if (this.geocoder)
            this.geocoder.geocode(
                {'location': {lat: gpsLocation.latitude, lng: gpsLocation.longtitude}},
                (results: GeocoderResult[]) => {
                    if (results !== null) {
                        let firstResult = results[0];
                        console.log('first geocoder result: ', firstResult);
                        if (firstResult !== null)
                            this.addresses.next(this.convertPlaceResultToAddressObject(firstResult.address_components, firstResult.geometry));
                    }
                });
    }

    private findAddressComponentByType(components: google.maps.GeocoderAddressComponent[], typeToFind: string): google.maps.GeocoderAddressComponent {
        return components.find(component => component.types.some(type => type === typeToFind));
    }

    private getAddressComponentStringByLongName(component: google.maps.GeocoderAddressComponent): string {
        return this.getAddressComponentStringBy(component, 'long_name');
    }

    private getAddressComponentStringBy(component: google.maps.GeocoderAddressComponent, mode: string): string {
        if (!component)
            return null;
        if (mode === 'long_name')
            return component.long_name;
        else return component.short_name;
    }

    public convertPlaceResultToAddressObject(addressComponent: google.maps.GeocoderAddressComponent[], geometry: google.maps.GeocoderGeometry): Address {
        return new Address({
          houseNr: this.getAddressComponentStringByLongName(this.findAddressComponentByType(addressComponent, 'street_number')),
            street: this.getAddressComponentStringByLongName(this.findAddressComponentByType(addressComponent, 'route')),
            ward: this.getAddressComponentStringByLongName(this.findAddressComponentByType(addressComponent, 'sublocality_level_1')),
            district: this.getAddressComponentStringByLongName(this.findAddressComponentByType(addressComponent, 'administrative_area_level_2')),
            province: this.getAddressComponentStringByLongName(this.findAddressComponentByType(addressComponent, 'administrative_area_level_1')),
            country: this.getAddressComponentStringByLongName(this.findAddressComponentByType(addressComponent, 'country')),
           gpslocation: new GPSLocation(geometry.location.lat(), geometry.location.lng())
 
        });
    }
}