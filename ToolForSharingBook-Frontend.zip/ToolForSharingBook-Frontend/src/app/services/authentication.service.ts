import {Injectable, Injector} from "@angular/core";
import {Http, Response} from "@angular/http";
import { Observable } from 'rxjs/Observable'
import { Router } from '@angular/router';
import {Login} from '../models/data/login.model';

import 'rxjs/add/operator/map'
import GenericService from "./generic.service";
import { contentHeaders } from '../technical/headers';
/**
 * Created by Vo on 6/6/2017.
 */
@Injectable()
export class AuthenticationService extends GenericService
{
  constructor(private injector:Injector, public http:Http, private router:Router){
    super(injector);
    this.BASE_URL+='users/login';
  }
 
 
  login(login:Login): Observable<Response> {
    return this.post(login);
  }

  finishAuthentication(token): void {
    localStorage.setItem('token', token)
    this.router.navigate(['map']);
  }

  logout(): void {
    localStorage.removeItem('token');
  }

}
