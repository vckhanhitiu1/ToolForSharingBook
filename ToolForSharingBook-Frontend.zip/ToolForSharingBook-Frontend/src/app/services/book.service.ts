/**
 * Created by Vo on 2/17/2017.
 */
import {Injectable, Injector} from "@angular/core";
import GenericService from "./generic.service";
import {Book} from "../models/data/Book.model";
import {Http, Response} from "@angular/http";
import {Observable} from "rxjs";
import 'rxjs/add/operator/map';

@Injectable()
export class BookService extends GenericService
{

  constructor(injector: Injector,  public _http:Http) {
    super(injector);
    this.BASE_URL += 'books';

  }

  GetListBook():Observable<Book[]>{
    return this.get();
  }
  PostBook(book:Book):Observable<Response>{
  	return this.post(book);
  }


}

