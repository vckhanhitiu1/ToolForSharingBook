import { Injectable } from '@angular/core';
import { CanActivate, Router,
  ActivatedRouteSnapshot,Route,
  RouterStateSnapshot } from '@angular/router';
import { tokenNotExpired } from 'angular2-jwt';
import {LogInService} from './login.service';

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private router: Router, private loginService:LogInService) {}

canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {    // let status = this.loginService.IsLogged();
    //     if (status == false){
    //         alert('You dont have permission access to this page');
    //     }
    //     return status;
    let url:string = state.url;
    return this.checkLogin(url);
  }
  canLoad(route: Route): boolean {
    let url = `/{route.path}`;

    return this.checkLogin(url);
  }

   checkLogin(url: string): boolean {
    if (this.loginService.isLoggedIn) { 
    	return true;
    	 }

       this.loginService.redirectUrl = url;

    // Store the attempted URL for redirecting

    // Create a dummy session id
    // let sessionId = 123456789;

    // Set our navigation extras object
    // that contains our global query params and fragment
    // let navigationExtras: NavigationExtras = {
    //   queryParams: { 'session_id': sessionId },
    //   fragment: 'anchor'
    // };

    // Navigate to the login page with extras
    this.router.navigate(['/login']);
    return false;
  }
}