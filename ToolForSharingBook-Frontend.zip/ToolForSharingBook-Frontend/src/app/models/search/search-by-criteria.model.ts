import {SearchCriteria} from "./search-criteria.model";

export  class SearchByCriteria
{
    criteria: Array<SearchCriteria> = [];

    or: Array<SearchByCriteria> = [] ;

    constructor(criteria?: Array<SearchCriteria> , or?: Array<SearchByCriteria>)
    {
        this.criteria= criteria;
        this.or = or;
    }

}