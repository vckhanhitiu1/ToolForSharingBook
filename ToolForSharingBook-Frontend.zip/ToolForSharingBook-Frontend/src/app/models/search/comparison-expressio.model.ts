export enum ComparisonExpression
{
    EQUAL,
    LIKE,
    NOT_EQUAL,
    GREATER_THAN,
    GREATER_THAN_OR_EQUAL,
    LESS_THAN,
    LESS_THAN_OR_EQUAL,
    BETWEEN,
    NOT_BETWEEN    
}