export class Login{

	username:string;
	password:string;
  passwordConfirm:string;
  email:string

}
