/**
 * Created by Vo on 2/16/2017.
 */
import {BookType} from './BookType.model';
import {BookStatus} from './BookStatus.model';
import {Authors} from './Author.model';
export class Book
{
  id?:number;
  title?:string;
  isbn?:string;
  price?:number;
  description?:string;
  copyright?:Date;
  edition?:number;
  booktype?:BookType;
  bookstatus?:BookStatus;
  authors?: string;
  image?: string;


  constructor(that:Book) {
    this.id = that.id;
    this.title = that.title;
    this.isbn = that.isbn;
    this.price = that.price;
    this.description = that.description;
    this.copyright = that.copyright;
    this.edition = that.edition;
    this.booktype = that.booktype;
    this.bookstatus = that.bookstatus;
    this.authors= that.authors;
    this.image= that.image;
  }
}
