/**
 * Created by Vo on 2/16/2017.
 */
export enum BookStatus
{
  PHYSICALBOOK,
  SOFTBOOK
}
