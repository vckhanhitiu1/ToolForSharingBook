package com.iu.edu.prethesis.technical;

import com.iu.edu.prethesis.data.MemberOrderFiled;
import com.iu.edu.prethesis.data.SortByCriteria;
import com.iu.edu.prethesis.data.SortCriteria;
import com.iu.edu.prethesis.data.bom.Member;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Created by Vo on 3/2/2017.
 */
public class MemberComparator implements Comparator<Member>{

    private SortByCriteria sortByCriteria;

    public MemberComparator(SortByCriteria sortByCriteria) {
        this.sortByCriteria = sortByCriteria;
    }

    @Override
    public int compare(Member thiz, Member that) {
        if(sortByCriteria==null || sortByCriteria.getOrder()==null)
        {
           return thiz.getAccountCode().compareTo(that.getAccountCode());
        }
        else
        {
            List<SortCriteria> copiesOnes = new ArrayList<SortCriteria>(sortByCriteria.getOrder());
            return compare(thiz,that,copiesOnes);
        }
    }


    public int compare(Member thiz, Member that, List<SortCriteria> orderCriterias) {

        SortCriteria orderCriteria = orderCriterias.remove(0);

        int result = compare(thiz, that, orderCriteria);
        if (orderCriterias.isEmpty()) {
            return result;
        }

        if (result != 0) {
            return result;
        }

        else {
            return compare(thiz, that, orderCriterias);
        }


    }
    public int compare(Member thiz, Member that,  SortCriteria orderCriteria)
    {
        if(MemberOrderFiled.NAME.getLiteral().equalsIgnoreCase(orderCriteria.getField()))
        {
            if(orderCriteria.isDescending())
            {
                return that.getName().compareTo(thiz.getName());
            }
            else
                return thiz.getName().compareTo(thiz.getName());
        }
        if(MemberOrderFiled.EMAIL.getLiteral().equalsIgnoreCase(orderCriteria.getField()))
        {
            if(orderCriteria.isDescending())
            {
                return that.getEmailAddress().compareTo(thiz.getEmailAddress());
            }
            else
                return thiz.getEmailAddress().compareTo(thiz.getEmailAddress());
        }
        else
            throw new UnsupportedOperationException();
    }

}
