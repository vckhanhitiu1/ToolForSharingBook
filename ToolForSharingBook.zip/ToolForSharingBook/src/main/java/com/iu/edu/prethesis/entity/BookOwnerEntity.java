package com.iu.edu.prethesis.entity;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by Vo on 6/7/2017.
 */
@Entity
@Table(name = "book_owner")
@NamedQueries({
        @NamedQuery(name = BookOwnerEntity.FIND_ALL, query = "SELECT b FROM BookOwnerEntity b"),

        @NamedQuery(name=BookOwnerEntity.FIND_BY_BOOK_ISBN, query ="SELECT i FROM BookOwnerEntity i  WHERE i.isbn =:isbn"),


})
public class BookOwnerEntity extends  GenericEntity implements Serializable{

    private static final String PREFIX = "com.iu.edu.prethesis.entity.BookOwnerEntity";

    public static final String FIND_ALL = PREFIX + ".findAll";

    public static final String FIND_BY_BOOK_ISBN = PREFIX +".findByBookIsbn";


    @Column(name = "isbn", nullable = false)
    private String isbn;

    @Column(name = "bookname", nullable = false)
    private String bookname;

    @Column(name = "member_code")
    private String membercode;

    @Column(name = "member_name")
    private String membername;

    public BookOwnerEntity() {
    }

    public BookOwnerEntity(String isbn, String bookname, String membercode, String membername) {
        this.isbn = isbn;
        this.bookname = bookname;
        this.membercode = membercode;
        this.membername = membername;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    public String getMembercode() {
        return membercode;
    }

    public void setMembercode(String membercode) {
        this.membercode = membercode;
    }

    public String getMembername() {
        return membername;
    }

    public void setMembername(String membername) {
        this.membername = membername;
    }
}
