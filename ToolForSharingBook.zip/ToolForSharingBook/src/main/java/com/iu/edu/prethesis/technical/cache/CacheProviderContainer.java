package com.iu.edu.prethesis.technical.cache;

import org.infinispan.commons.api.BasicCache;
import org.infinispan.commons.api.BasicCacheContainer;
import org.infinispan.configuration.cache.CacheMode;
import org.infinispan.configuration.cache.Configuration;
import org.infinispan.configuration.cache.ConfigurationBuilder;
import org.infinispan.configuration.global.GlobalConfiguration;
import org.infinispan.configuration.global.GlobalConfigurationBuilder;
import org.infinispan.manager.DefaultCacheManager;
import org.infinispan.util.concurrent.IsolationLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Singleton;
import javax.ejb.Startup;


/**
 * Created by Vo on 2/17/2017.
 */

@Singleton
@Startup
public class CacheProviderContainer{

    private static final Logger logger = LoggerFactory.getLogger(CacheProviderContainer.class);

    BasicCacheContainer manager;

    @PostConstruct
    public void initCacheContainer()
    {

        logger.info("**************Start Cache**************");
        if(manager==null)
        {
            GlobalConfiguration global  = new GlobalConfigurationBuilder().nonClusteredDefault()
                    .globalJmxStatistics().allowDuplicateDomains(true).build();

            Configuration loc = new ConfigurationBuilder()
                    .clustering().cacheMode(CacheMode.LOCAL).locking().isolationLevel(IsolationLevel.REPEATABLE_READ)
                    .persistence().passivation(false).addSingleFileStore().purgeOnStartup(true).build();

            manager = new DefaultCacheManager(global, loc, true);
            logger.info("********* initCacheContainer **********" + manager);


        }

    }

    public <K, V> BasicCache<K, V> getCache(Class<V> clazz) {
        return this.manager.getCache(clazz.getName());
    }



    @PreDestroy
    public void cleanUp() {
        manager.stop();
        manager = null;
    }



}
