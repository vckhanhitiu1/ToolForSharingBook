package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.data.BookSearchField;
import com.iu.edu.prethesis.data.SearchCriteria;
import com.iu.edu.prethesis.data.SortByCriteria;
import com.iu.edu.prethesis.data.bom.Book;
import com.iu.edu.prethesis.technical.BookComparator;
import com.iu.edu.prethesis.technical.ComparisonExpressionEvaluator;
import com.iu.edu.prethesis.technical.cache.CacheProviderContainer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;

/**
 * Created by Vo on 3/2/2017.
 */
@Stateless
public class BookCacheService extends GenericCacheService<String,Book> implements Serializable{

    private final Logger logger = LoggerFactory.getLogger(BookCacheService.class);

    @EJB
    CacheProviderContainer cacheProviderContainer;

    @Override
    protected void sort(List<Book> list, SortByCriteria orderBy) {
        Collections.sort(list,new BookComparator(orderBy));

    }

    public BookCacheService() {
    }

    @Override
    public Predicate<Book> createSingleSearchCondition(SearchCriteria criteria) {
        if(BookSearchField.ISBN.getLiteral().equalsIgnoreCase(criteria.getField()))
        {
            return new Predicate<Book>(){
                @Override
                public boolean test(Book s) {
                    return ComparisonExpressionEvaluator.evaluate(s.getIsbn(), criteria.getExpression(), criteria.getValue().toString());
                }
            };
        }
        if(BookSearchField.NAME.getLiteral().equalsIgnoreCase(criteria.getField()))
        {
            return new Predicate<Book>(){
                @Override
                public boolean test(Book s) {
                    return ComparisonExpressionEvaluator.evaluate(s.getBookname(), criteria.getExpression(), criteria.getValue().toString());
                }
            };
        }
        if(BookSearchField.TYPE.getLiteral().equalsIgnoreCase(criteria.getField()))
        {
            return new Predicate<Book>(){
                @Override
                public boolean test(Book s) {
                    return ComparisonExpressionEvaluator.evaluate(s.getBooktype().toString(), criteria.getExpression(), criteria.getValue().toString());
                }
            };
        }
        if(BookSearchField.STATUS.getLiteral().equalsIgnoreCase(criteria.getField()))
        {
            return new Predicate<Book>(){
                @Override
                public boolean test(Book s) {
                    return ComparisonExpressionEvaluator.evaluate(s.getStatus().toString(), criteria.getExpression(), criteria.getValue().toString());
                }
            };
        }
        throw new UnsupportedOperationException();

    }

    @PostConstruct
    public void initCache()
    {
        setCache(cacheProviderContainer.<String,Book> getCache(Book.class));
    }



}
