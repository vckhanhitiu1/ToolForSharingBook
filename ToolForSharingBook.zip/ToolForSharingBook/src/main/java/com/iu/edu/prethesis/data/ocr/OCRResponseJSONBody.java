package com.iu.edu.prethesis.data.ocr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Created by Vo on 5/28/2017.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class OCRResponseJSONBody {

    private String language;

    private String textAngle;

    private String orientation;

    private List<Regions> regions;

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getTextAngle() {
        return textAngle;
    }

    public void setTextAngle(String textAngle) {
        this.textAngle = textAngle;
    }

    public String getOrientation() {
        return orientation;
    }

    public void setOrientation(String orientation) {
        this.orientation = orientation;
    }

    public List <Regions> getRegions() {
        return regions;
    }

    public void setRegions(List <Regions> regions) {
        this.regions = regions;
    }

    public class Regions{
        private String boundingBox;
        private List<Lines> lines;

        public String getBoundingBox() {
            return boundingBox;
        }

        public void setBoundingBox(String boundingBox) {
            this.boundingBox = boundingBox;
        }

        public List <Lines> getLines() {
            return lines;
        }

        public void setLines(List <Lines> lines) {
            this.lines = lines;
        }
    }

    public class Lines{
        private String boundingBox;
        private List<Words> words;

        public String getBoundingBox() {
            return boundingBox;
        }

        public void setBoundingBox(String boundingBox) {
            this.boundingBox = boundingBox;
        }

        public List <Words> getWords() {
            return words;
        }

        public void setWords(List <Words> words) {
            this.words = words;
        }
    }

   public class Words{
        private String boundingBox;
        private String text;

        public String getBoundingBox() {
            return boundingBox;
        }

        public void setBoundingBox(String boundingBox) {
            this.boundingBox = boundingBox;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }
    }

}
