package com.iu.edu.prethesis.data.authbom;

public class AuthenticationException extends Exception {

    public AuthenticationException( String msg ) {
        super( msg );
    }
}
