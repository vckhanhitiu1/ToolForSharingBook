package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.data.RangeCriteria;
import com.iu.edu.prethesis.data.SearchByCriteria;
import com.iu.edu.prethesis.data.SearchCriteria;
import com.iu.edu.prethesis.data.SortByCriteria;
import org.infinispan.commons.api.BasicCache;


/**
 * Created by Vo on 2/2/2017.
 */


import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public abstract class GenericCacheService<K, V> {

    protected BasicCache<K, V> cache;

    public void put(K key, V value) {
        if (key != null && value != null) {
            this.cache.put(key, value);
        }
    }

    public V get(K key) {
        if (key == null) {
            return null;
        }
        return this.cache.get(key);
    }

    public List<V> values() {
        Collection<V> all = this.cache.values();
        return new ArrayList<V>(all);
    }

    public void remove(Object key) {
        if (key != null) {
            this.cache.remove(key);
        }
    }

    public void clearAll() {
        this.cache.clear();
    }

    public Set<K> keySet() {
        Set<K> keySet = this.cache.keySet();
        return new HashSet<K>(keySet);
    }

    public List<V> search(SearchByCriteria searchBy, SortByCriteria orderBy, RangeCriteria range) {
        List<V> input = this.values();
        List<V> output = new ArrayList<V>();
        if (searchBy == null || (searchBy.getCriteria() == null && searchBy.getOr() == null)) {
            output.addAll(input);
        }

        else {
            search(input, searchBy.getCriteria() , output);
            List<SearchByCriteria> or = searchBy.getOr();
            if (or != null && !or.isEmpty()) {
                or.forEach(new Consumer<SearchByCriteria>(){
                    @Override
                    public void accept(SearchByCriteria each) {
                        search(input, each.getCriteria(), output);
                    }
                });
            }
        }

        List<V> uniqueResultList = removeDuplicates(output);

        sort(uniqueResultList, orderBy);

        return range(uniqueResultList, range);
    }

    protected abstract void sort(List<V> list, SortByCriteria orderBy);

    private List<V> range(List<V> list, RangeCriteria range) {
        if (range == null) {
            return list;
        }
        if (list == null || list.isEmpty()) {
            return list;
        }

        Integer from = (range.getFrom() == null)? 0 : range.getFrom();
        Integer to = (range.getTo() == null || range.getTo() > list.size())? list.size() : range.getTo();

        return list.subList(from, to);
    }

    private void search(List<V> input, List<SearchCriteria> criterias, List<V> output) {
        if (criterias != null && !criterias.isEmpty()) {
            output.addAll(input.stream()
                    .filter(createCondition(criterias))
                    .collect(Collectors.toList()));
        }
    }

    private Predicate<V> createCondition(List<SearchCriteria> criterias) {
        if (criterias == null) {
            return null;
        }

        Predicate<V> predicate = null;
        for (SearchCriteria each : criterias) {
            if (predicate == null) {
                predicate = createSingleSearchCondition(each);
            }
            else {
                predicate = predicate.and(createSingleSearchCondition(each));
            }
        }
        return predicate;
    }

    public abstract Predicate<V> createSingleSearchCondition(SearchCriteria criteria);


    public BasicCache<K, V> getCache() {
        return cache;
    }

    public void setCache(BasicCache<K, V> cache) {
        this.cache = cache;
    }


    private List<V> removeDuplicates(List<V> list){
        List<V> result = new ArrayList<V>();
        HashSet<V> set = new HashSet<V>();
        list.stream().filter(new Predicate<V>(){
            @Override
            public boolean test(V item) {
                return !set.contains(item);
            }
        }).forEach(new Consumer<V>(){
            @Override
            public void accept(V item) {
                result.add(item);
                set.add(item);
            }
        });
        return result;
    }

}





