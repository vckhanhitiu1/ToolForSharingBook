package com.iu.edu.prethesis.rest;

import com.iu.edu.prethesis.data.auth.JwtManager;
import com.iu.edu.prethesis.data.authbom.AuthenticationException;
import com.iu.edu.prethesis.data.authbom.LogInUser;
import com.iu.edu.prethesis.data.authbom.dto.LoginRequest;
import com.iu.edu.prethesis.data.authbom.dto.LoginResponse;
import com.iu.edu.prethesis.entity.LogInUserEntity;
import com.iu.edu.prethesis.services.LogInService;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.net.URI;
import java.util.List;


/**
 * Created by Vo on 6/4/2017.
 */
@Stateless
@Path("/users")
public class LogInResource  {

    @Context
    private UriInfo uriInfo;
    @PersistenceContext(name="thesisprojectPU")
    private EntityManager em;

    @EJB
    LogInService logInService;

    @Inject
    private JwtManager jwtManager;


    @Path("addnew")
    @POST
    @PermitAll
    @Consumes({MediaType.APPLICATION_FORM_URLENCODED, MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response registerAccount(@Valid LogInUser logInUser)
    {
        logInService.save(logInUser);
        URI authorUri = uriInfo.getAbsolutePathBuilder().path(logInUser.getId().toString()).build();
        return Response .created(authorUri).build();
    }
    @POST
    @Path( "login" )
    @PermitAll
    @Consumes({MediaType.APPLICATION_FORM_URLENCODED,MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_FORM_URLENCODED})
    public Response login(LoginRequest loginRequest ) {
        try {
            LogInUserEntity user = logInService.authenticate( loginRequest.getUsername(), loginRequest.getPassword() );
            String jwt = jwtManager.createToken( user.getUsername(), user.getRoles() );
            LoginResponse response = new LoginResponse( user.getUsername(), user.getRoles(), jwt );
            return Response.ok().entity(response).type(MediaType.APPLICATION_JSON).build();
        } catch ( AuthenticationException e ) {
            return Response.noContent().status(Response.Status.UNAUTHORIZED).build();
        }
    }


    @GET
    @Path("showall")
    @PermitAll
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    public List<LogInUserEntity> getAllAccount()
    {
        return logInService.findAll();
    }

}
