package com.iu.edu.prethesis.rest;

import com.iu.edu.prethesis.data.bom.BookOwner;
import com.iu.edu.prethesis.entity.BookEntity;
import com.iu.edu.prethesis.entity.BookOwnerEntity;
import com.iu.edu.prethesis.services.BookOwnerService;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.net.URI;
import java.util.List;

/**
 * Created by Vo on 6/8/2017.
 */
@Stateless
@Path(value = "/bookowners")
public class BookOwnerResource {

    @Context
    private UriInfo uriInfo;

    @PersistenceContext(name = "thesisprojectPU")
    private EntityManager em;

    @EJB
    BookOwnerService bookOwnerService;

    @POST
    @Consumes(value = MediaType.APPLICATION_JSON)
    @Produces(value = MediaType.APPLICATION_JSON)
    public Response creatBook(@Valid BookOwner bookOwner) throws Exception {
        bookOwnerService.save(bookOwner);
        URI bookUri =uriInfo.getAbsolutePathBuilder().path(bookOwner.getId().toString()).build();
        return Response.created(bookUri).build();
    }

    @GET
    @Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_JSON})
    public List<BookOwnerEntity> getAll()
    {
        return bookOwnerService.findAll();
    }

    @GET
    @Path("{isbn}")
    @Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_JSON})
    public List<BookOwnerEntity> getByISBN(@PathParam("isbn") String isbn)
    {
     List<BookOwnerEntity> bookOwnerEntity = bookOwnerService.findListByBookIsbn(isbn);
     if(bookOwnerEntity!=null)
     {
         return bookOwnerEntity ;
     }
     else
         throw new NotFoundException("Book does not exist");
    }


}
