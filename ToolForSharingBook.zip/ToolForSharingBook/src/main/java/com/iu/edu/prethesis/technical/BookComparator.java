package com.iu.edu.prethesis.technical;

import com.iu.edu.prethesis.data.BookOrderField;
import com.iu.edu.prethesis.data.SortByCriteria;
import com.iu.edu.prethesis.data.SortCriteria;
import com.iu.edu.prethesis.data.bom.Book;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Created by Vo on 2/17/2017.
 */
public class BookComparator implements Comparator<Book>{

    private SortByCriteria sortByCriteria;

    public BookComparator(SortByCriteria sortByCriteria) {
        this.sortByCriteria = sortByCriteria;
    }

    @Override
    public int compare(Book thiz, Book that) {
        if(sortByCriteria==null || sortByCriteria.getOrder()==null || sortByCriteria.getOrder().isEmpty())
        {
            return thiz.getIsbn().compareTo(that.getIsbn());

        }
        else
        {
            List<SortCriteria> copiedOnes = new ArrayList<SortCriteria>(sortByCriteria.getOrder());
            return compare(thiz, that, copiedOnes);
        }
    }

    public int compare(Book thiz, Book that, List<SortCriteria> orderCriterias) {

        SortCriteria orderCriteria = orderCriterias.remove(0);

        int result = compare(thiz, that, orderCriteria);
        if (orderCriterias.isEmpty()) {
            return result;
        }

        if (result != 0) {
            return result;
        }

        else {
            return compare(thiz, that, orderCriterias);
        }


    }

    public int compare(Book thiz, Book that,  SortCriteria orderCriteria)
    {
        if(BookOrderField.NAME.getLiteral().equalsIgnoreCase(orderCriteria.getField()))
        {
           if(orderCriteria.isDescending())
           {
               return that.getBookname().compareTo(thiz.getBookname());
           }
           else
               return thiz.getBookname().compareTo(thiz.getBookname());
        }
        if(BookOrderField.ISBN.getLiteral().equalsIgnoreCase(orderCriteria.getField()))
        {
            if(orderCriteria.isDescending())
            {
                return that.getIsbn().compareTo(thiz.getIsbn());
            }
        }
        if(BookOrderField.TYPE.getLiteral().equalsIgnoreCase(orderCriteria.getField()))
        {
            if(orderCriteria.isDescending())
            {
                return that.getBooktype().compareTo(thiz.getBooktype());
            }
            else
                return thiz.getBooktype().compareTo(thiz.getBooktype());
        }
        if(BookOrderField.STATUS.getLiteral().equalsIgnoreCase(orderCriteria.getField()))
        {
            if(orderCriteria.isDescending())
            {
                return that.getStatus().compareTo(thiz.getStatus());
            }
            else
                return thiz.getStatus().compareTo(thiz.getStatus());
        }
        else
            throw  new UnsupportedOperationException();

    }





}
