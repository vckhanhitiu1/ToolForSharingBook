package com.iu.edu.prethesis.data.addrbom;

import java.io.Serializable;

public class Province implements Serializable {

    /*
     *
     */
    private Integer id;

    /*
     *
     */
    private String name;

    /*
     *
     */
    private String shortName;

    /*
     *
     */
    private Integer countryId;

    public Province() {

    }

    public Province(Integer id, String name, String shortName, Integer countryId) {
        super();
        this.id = id;
        this.name = name;
        this.shortName = shortName;
        this.countryId = countryId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public Integer getCountryId() {
        return countryId;
    }

    public void setCountryId(Integer countryId) {
        this.countryId = countryId;
    }

    @Override
    public String toString() {
        return "Province [id=" + id + ", name=" + name + ", shortName=" + shortName + ", countryId=" + countryId + "]";
    }


}
