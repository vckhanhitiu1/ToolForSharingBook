package com.iu.edu.prethesis.data.addrbom;

import com.iu.edu.prethesis.entity.GPSLocationEntity;

import java.io.Serializable;

public class GPSLocation implements Serializable {

    /*
     *
     */
    private Float longtitude;
    /*
     *
     */
    private Float latitude;

    public GPSLocation() {

    }

    public GPSLocation(Float longtitude, Float latitude) {
        super();
        this.longtitude = longtitude;
        this.latitude = latitude;
    }

    public Float getLongtitude() {
        return longtitude;
    }

    public void setLongtitude(Float longtitude) {
        this.longtitude = longtitude;
    }

    public Float getLatitude() {
        return latitude;
    }

    public void setLatitude(Float latitude) {
        this.latitude = latitude;
    }

    @Override
    public String toString() {
        return "GPSLocation [longtitude=" + longtitude + ", latitude=" + latitude + "]";
    }


    public static GPSLocation fromEntity(GPSLocationEntity entity)
    {
        if(entity==null)
        {
            return null;
        }
        GPSLocation bom = new GPSLocation();
        bom.setLatitude(entity.getLatitude());
        bom.setLongtitude(entity.getLongtitude());
        return bom;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((latitude == null) ? 0 : latitude.hashCode());
        result = prime * result + ((longtitude == null) ? 0 : longtitude.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        GPSLocation other = (GPSLocation) obj;
        if (latitude == null) {
            if (other.latitude != null)
                return false;
        } else if (!latitude.equals(other.latitude))
            return false;
        if (longtitude == null) {
            if (other.longtitude != null)
                return false;
        } else if (!longtitude.equals(other.longtitude))
            return false;
        return true;
    }


}
