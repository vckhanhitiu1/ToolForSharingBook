package com.iu.edu.prethesis.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * Created by Vo on 6/4/2017.
 */
@Entity
@Table(name="log_in")
@NamedQueries({
        @NamedQuery(name = LogInUserEntity.FIND_ALL, query = "SELECT l FROM LogInUserEntity l"),
        @NamedQuery(name = LogInUserEntity.FIND_BY_USERNAME_AND_PASSWORD, query =
                "SELECT u FROM LogInUserEntity u WHERE u.username =:username AND u.password =:password")
})
public class LogInUserEntity extends GenericEntity implements Serializable {

    private static final String PREFIX = "com.iu.edu.prethesis.entity.LogInUserEntity";

    public static final String FIND_ALL =PREFIX + ".findAll";

    public static final String FIND_BY_USERNAME_AND_PASSWORD = PREFIX + ".findByUserNameAndPassword";


    @Column(name="user_name",nullable = false, unique = true)
    private String username;

    @Column(name = "pass_word",nullable = false, unique = true)
    private String password;

    @Column(name = "confirm_password", nullable = false, unique = true)
    private String confirmpassword;

    @Column(name = "roles")
    private String roles;

    @Column(name = "email", nullable = false)
    private String email;

    public LogInUserEntity(String username, String password, String roles) {
        this.username = username;
        this.password = password;
        this.roles = roles;
    }

    public LogInUserEntity(String username, String password, String confirmpassword, String roles) {
        this.username = username;
        this.password = password;
        this.confirmpassword = confirmpassword;
        this.roles = roles;
    }



    public LogInUserEntity() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRoles() {
        return roles;
    }

    public void setRoles(String roles) {
        this.roles = roles;
    }

    public String getConfirmpassword() {
        return confirmpassword;
    }

    public void setConfirmpassword(String confirmpassword) {
        this.confirmpassword = confirmpassword;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
