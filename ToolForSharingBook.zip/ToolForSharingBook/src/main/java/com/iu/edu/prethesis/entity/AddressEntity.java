package com.iu.edu.prethesis.entity;

import javax.persistence.*;
import java.io.Serializable;


@Entity
@Table(name = "address")
@NamedQueries({
        @NamedQuery(name = AddressEntity.FIND_BY_MEMBER_ID, query = "SELECT a FROM AddressEntity a WHERE a.memberId= :memberId ")
})
public class AddressEntity extends GenericEntity implements Serializable{

    private static final String PREFIX = "com.iu.edu.prethesis.entity.MemberEntity";

    public static final String FIND_BY_MEMBER_ID = PREFIX + ".findByMemberId";


    @Column(name = "member_id",nullable = false)
    private Integer memberId;

    @Column(name = "country", nullable = false)
    private String country;

    @Column(name = "province", nullable = false)
    private String province;

    @Column(name = "district")
    private String district;

    @Column(name = "ward")
    private String ward;

    @Column(name = "street")
    private String street;

    @Column(name = "house_number")
    private String houseNr;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "gps_location_id", referencedColumnName = "id")
    private GPSLocationEntity gpsLocation;

    public AddressEntity() {

    }


    public AddressEntity(Integer memberId, String country, String province, String district, String ward, String street, String houseNr, GPSLocationEntity gpsLocation) {
        this.memberId = memberId;
        this.country = country;
        this.province = province;
        this.district = district;
        this.ward = ward;
        this.street = street;
        this.houseNr = houseNr;
        this.gpsLocation = gpsLocation;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getHouseNr() {
        return houseNr;
    }

    public void setHouseNr(String houseNr) {
        this.houseNr = houseNr;
    }

    public GPSLocationEntity getGpsLocation() {
        return gpsLocation;
    }

    public void setGpsLocation(GPSLocationEntity gpsLocation) {
        this.gpsLocation = gpsLocation;
    }

    @Override
    public String toString() {
        return "AddressEntity [ country=" + country + ", province=" + province + ", district="
                + district + ", ward=" + ward + ", street=" + street + ", houseNr=" + houseNr + ", gpsLocation="
                + gpsLocation + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((country == null) ? 0 : country.hashCode());
        result = prime * result + ((district == null) ? 0 : district.hashCode());
        result = prime * result + ((gpsLocation == null) ? 0 : gpsLocation.hashCode());
        result = prime * result + ((houseNr == null) ? 0 : houseNr.hashCode());
        result = prime * result + ((province == null) ? 0 : province.hashCode());
        result = prime * result + ((street == null) ? 0 : street.hashCode());
       
        result = prime * result + ((ward == null) ? 0 : ward.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        AddressEntity other = (AddressEntity) obj;
        if (country == null) {
            if (other.country != null)
                return false;
        } else if (!country.equals(other.country))
            return false;
        if (district == null) {
            if (other.district != null)
                return false;
        } else if (!district.equals(other.district))
            return false;
        if (gpsLocation == null) {
            if (other.gpsLocation != null)
                return false;
        } else if (!gpsLocation.equals(other.gpsLocation))
            return false;
        if (houseNr == null) {
            if (other.houseNr != null)
                return false;
        } else if (!houseNr.equals(other.houseNr))
            return false;
        if (province == null) {
            if (other.province != null)
                return false;
        } else if (!province.equals(other.province))
            return false;
        if (street == null) {
            if (other.street != null)
                return false;
        } else if (!street.equals(other.street))
            return false;
        if (ward == null) {
            if (other.ward != null)
                return false;
        } else if (!ward.equals(other.ward))
            return false;
        return true;
    }


}
