package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.data.authbom.AuthenticationException;
import com.iu.edu.prethesis.data.authbom.LogInUser;
import com.iu.edu.prethesis.entity.LogInUserEntity;

import javax.ejb.Stateless;
import javax.persistence.TypedQuery;
import javax.validation.Valid;
import java.util.List;

/**
 * Created by Vo on 6/4/2017.
 */
@Stateless
public class LogInService extends GenericService<LogInUserEntity,LogInUser>{


    public LogInService() {
        super(LogInUserEntity.class);
    }

    public List<LogInUserEntity> findAll()
    {
        TypedQuery<LogInUserEntity> query = em.createNamedQuery(LogInUserEntity.FIND_ALL,LogInUserEntity.class);
        return query.getResultList();
    }

    public void save(@Valid  LogInUser logInUser)
    {
//        LogInUserEntity previousLogInUserEntity= this.findByUserNameAndPassword(logInUser.getUsername(),logInUser.getPassword());
        LogInUserEntity logInUserEntity = this.toEntity(logInUser);
        try {
            if (logInUserEntity.getPassword().equals(logInUserEntity.getConfirmpassword())) {
//        if(previousLogInUserEntity!=null && previousLogInUserEntity.getUsername().equals(logInUserEntity.getUsername())
//                && previousLogInUserEntity.getPassword().equals(logInUserEntity.getPassword()))
//        {
//            this.save(previousLogInUserEntity);
//        }
                this.save(logInUserEntity);
                logInUser.setId(logInUserEntity.getId());
            }
        }
        catch (Exception e)
        {
            System.out.print("Can not save");
        }


    }

    @Override
    public LogInUserEntity toEntity(LogInUser bom) {
        if(bom ==null) {
            return null;
        }

        LogInUserEntity entity = new LogInUserEntity();
        entity.setUsername(bom.getUsername());
        entity.setPassword(bom.getPassword());
        entity.setConfirmpassword(bom.getPasswordConfirm());
        entity.setRoles(bom.getRoles());
        entity.setEmail(bom.getEmail());

        return entity;
    }
    private List<LogInUserEntity> findByUserNameAndPassword(String username, String password)
    {
        TypedQuery<LogInUserEntity> query = em.createNamedQuery(LogInUserEntity.FIND_BY_USERNAME_AND_PASSWORD,LogInUserEntity.class);
        query.setParameter("username", username);
        query.setParameter("password", password);
        List<LogInUserEntity> result = query.getResultList();
       if(result==null)
           return null;
       return result;
    }

    public LogInUserEntity authenticate(String username, String password) throws AuthenticationException
    {
        List<LogInUserEntity> logInUserEntities = this.findByUserNameAndPassword(username,password);
        if(logInUserEntities!=null){
        for(LogInUserEntity logInUserEntity: logInUserEntities) {
            if (logInUserEntity.getUsername().equals(username)
                    && logInUserEntity.getPassword().equals(password)) {
                return logInUserEntity;
            }
        }
        }
        throw new AuthenticationException( "Failed logging in user with name '" + username
                + "': unknown username or wrong password" );
    }

    @Override
    public LogInUser toBom(LogInUserEntity entity) {
        return null;
    }
}
