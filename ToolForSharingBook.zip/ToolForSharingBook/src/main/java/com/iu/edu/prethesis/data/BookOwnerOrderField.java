package com.iu.edu.prethesis.data;

/**
 * Created by Vo on 6/8/2017.
 */
public enum  BookOwnerOrderField {

    BOOK_NAME("bookname"),

    ISBN ("isbn");

    private String literal;

    BookOwnerOrderField(String literal) {
        this.literal = literal;
    }

    public String getLiteral() {
        return literal;
    }

    public void setLiteral(String literal) {
        this.literal = literal;
    }
}
