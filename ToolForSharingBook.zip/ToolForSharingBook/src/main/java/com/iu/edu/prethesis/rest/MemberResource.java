package com.iu.edu.prethesis.rest;

import com.iu.edu.prethesis.data.RangeCriteria;
import com.iu.edu.prethesis.data.SearchByCriteria;
import com.iu.edu.prethesis.data.SortByCriteria;
import com.iu.edu.prethesis.data.bom.Member;
import com.iu.edu.prethesis.entity.BookEntity;
import com.iu.edu.prethesis.entity.MemberEntity;
import com.iu.edu.prethesis.services.MemberFacade;
import com.iu.edu.prethesis.services.MemberService;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.net.URI;
import java.util.List;

/**
 * Created by Vo on 1/30/2017.
 */
@Stateless
@Path("/members")
public class MemberResource{
    @Context
    private UriInfo uriInfo;
    @PersistenceContext(name = "thesisprojectPU")
    private EntityManager em;

    @EJB
    MemberFacade memberFacade;

    @EJB
    MemberService memberService;


    @GET
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public List<Member> search(@QueryParam("searchBy")SearchByCriteria searchByCriteria,
                               @QueryParam("orderBy")SortByCriteria sortByCriteria,
                               @QueryParam("range") RangeCriteria rangeCriteria
                               )
    {
        return memberFacade.search(searchByCriteria,sortByCriteria,rangeCriteria);
    }


    @GET
    @Path("search")
    @Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_JSON})
    public List<MemberEntity> getAll()
    {
        return memberService.findAll();
    }


    @GET
    @Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    @Path("{code}")
    public MemberEntity getMemberByFindMemberCode(@PathParam("code") String code)
    {
        MemberEntity memberEntity = memberService.findByCode(code);
        if(memberEntity!=null)
        {
            return memberEntity;
        }
        else
            throw  new NotFoundException("Can not find member");
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createMember(@Valid Member member)
    {
        memberFacade.save(member);
        URI memberUri =uriInfo.getAbsolutePathBuilder().path(member.getId().toString()).build();
        return Response.created(memberUri).build();

    }
}
