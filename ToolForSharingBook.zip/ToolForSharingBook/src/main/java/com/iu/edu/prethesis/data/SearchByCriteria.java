package com.iu.edu.prethesis.data;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;

/**
 * Created by Vo on 2/3/2017.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SearchByCriteria implements Serializable{

    private static final long serialVersionUID =1L;

    private List<SearchCriteria> criteria = null;

    private List<SearchByCriteria> or = null;

    public SearchByCriteria() {
    }

    public SearchByCriteria(String json) throws IOException
    {
        SearchByCriteria queryObject;
        ObjectMapper mapper = new ObjectMapper();
        mapper.findAndRegisterModules();

        mapper.enable(DeserializationFeature.READ_ENUMS_USING_TO_STRING);
        queryObject= mapper.readValue(json,SearchByCriteria.class);
        this.criteria=queryObject.criteria;
        this.or=queryObject.or;

    }

    public static SearchByCriteria fromString(String json) throws IOException
    {
        if(json==null)
        {
            return null;
        }
        ObjectMapper mapper = new ObjectMapper();
        mapper.findAndRegisterModules();
        mapper.enable(DeserializationFeature.READ_ENUMS_USING_TO_STRING);
        return mapper.readValue(json , SearchByCriteria.class);
    }

    public List<SearchCriteria> getCriteria() {
        return criteria;
    }

    public void setCriteria(List<SearchCriteria> criteria) {
        this.criteria = criteria;
    }

    public List<SearchByCriteria> getOr() {
        return or;
    }

    public void setOr(List<SearchByCriteria> or) {
        this.or = or;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("EISearchByCriteria - ");
        if (criteria != null) {
            builder.append("criteria: ");
            for (SearchCriteria cri : criteria) {
                builder.append(cri).append(";");
            }
        } else {
            builder.append("no criteria;");
        }
        if (or != null) {
            builder.append("or: ");
            for (SearchByCriteria entry : or) {
                builder.append(entry).append(";");
            }
        } else {
            builder.append("no or");
        }
        return builder.toString();
    }
}
