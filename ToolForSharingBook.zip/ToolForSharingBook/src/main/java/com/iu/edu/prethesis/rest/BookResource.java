package com.iu.edu.prethesis.rest;

import com.iu.edu.prethesis.data.RangeCriteria;
import com.iu.edu.prethesis.data.SearchByCriteria;
import com.iu.edu.prethesis.data.SortByCriteria;
import com.iu.edu.prethesis.data.bom.Book;
import com.iu.edu.prethesis.data.bom.BookType;
import com.iu.edu.prethesis.data.bom.Member;
import com.iu.edu.prethesis.data.bom.Status;
import com.iu.edu.prethesis.entity.BookEntity;
import com.iu.edu.prethesis.services.BookFacade;
import com.iu.edu.prethesis.services.BookService;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.net.URI;
import java.util.Date;
import java.util.List;
/**
 * Created by Vo on 12/31/2016.
 */

@Stateless
@Path(value = "/books")
public class BookResource {

    @Context
    private UriInfo uriInfo;

    @PersistenceContext(name = "thesisprojectPU")
    private EntityManager em;

    @EJB
    BookFacade bookFacade;

    @EJB
    BookService bookService;

    @POST
    @Consumes(value = MediaType.APPLICATION_JSON)
    @Produces(value = MediaType.APPLICATION_JSON)
    public Response creatBook(@Valid Book book) {
        bookFacade.save(book);
        URI bookUri = uriInfo.getAbsolutePathBuilder().path(book.getId().toString()).build();
        return Response.created(bookUri).build();
    }

    @GET
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_JSON})
    public List <BookEntity> getAll() {

        return bookService.findAll();
    }

    @Path("search")
    @GET
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public List <Book> search(@QueryParam("searchBy") SearchByCriteria searchByCriteria,
                              @QueryParam("sortBy") SortByCriteria sortByCriteria,
                              @QueryParam("range") RangeCriteria rangeCriteria
    ) {
        return bookFacade.search(searchByCriteria, sortByCriteria, rangeCriteria);
    }


    @DELETE
    @Path(value = "{id}")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response deleteBook(@PathParam(value = "id") Integer id) {
        bookService.removeById(id);
        return Response.noContent().build();
    }

    @DELETE
    @Path("{isbn}")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public void deleteBookByIsbn(@PathParam("isbn") String isbn) {
        BookEntity bookEntity = bookService.findByIsbn(isbn);
        if (bookEntity != null) {
            bookService.removeById(bookEntity.getId());
        } else
            throw new NotFoundException("Can not Find Book'");
    }

    @GET
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("{isbn}")
    public BookEntity getBookByFindIsbn(@PathParam("isbn") String isbn) {
        BookEntity bookEntity = bookService.findByIsbn(isbn);
        if (bookEntity != null) {
            return bookEntity;
        } else
            throw new NotFoundException("Can not Find Book");
    }

    @PUT
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("{isbn}")
    public Response updateBookInfo(Book book)
    {
        bookService.updateBookInfoByISBN(book);
        return Response.ok().build();
    }


    }




