package com.iu.edu.prethesis.data.addrbom;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@SuppressWarnings("serial")
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Address implements Serializable {

    /*
     *
     */
    private Integer id;

    /*
     *
     */
    private Integer memberId;

    /**
     *
     */
    @Size(max = 50)
    private String country;
    /*
     *
     */
    @Size(max = 50)
    private String province;
    /*
     *
     */
    @Size(max = 50)
    private String district;
    /*
     *
     */
    @Size(max = 50)
    private String ward;
    /*
     *
     */
    @Size(max = 50)
    private String street;

    private String houseNr;

    @NotNull
    private GPSLocation gpslocation;


    public Address(Integer id, Integer memberId, String country, String province, String district, String ward, String street, String houseNr, GPSLocation gpslocation) {
        this.id = id;
        this.memberId = memberId;
        this.country = country;
        this.province = province;
        this.district = district;
        this.ward = ward;
        this.street = street;
        this.houseNr = houseNr;
        this.gpslocation = gpslocation;
    }

    public Address() {

    }
    /*
     *
	 */


    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public GPSLocation getGpslocation() {
        return gpslocation;
    }

    public void setGpslocation(GPSLocation gpslocation) {
        this.gpslocation = gpslocation;
    }

    public Integer getId() {
        return id;
    }


    public void setId(Integer id) {
        this.id = id;
    }


    public String getCountry() {
        return country;
    }


    public void setCountry(String country) {
        this.country = country;
    }


    public String getProvince() {
        return province;
    }


    public void setProvince(String province) {
        this.province = province;
    }


    public String getDistrict() {
        return district;
    }


    public void setDistrict(String district) {
        this.district = district;
    }


    public String getWard() {
        return ward;
    }


    public void setWard(String ward) {
        this.ward = ward;
    }


    public String getStreet() {
        return street;
    }


    public void setStreet(String street) {
        this.street = street;
    }


    public String getHouseNr() {
        return houseNr;
    }


    public void setHouseNr(String houseNr) {
        this.houseNr = houseNr;
    }


    @Override
    public String toString() {
        return "Address [id=" + id + ", country=" + country + ", province=" + province
                + ", district=" + district + ", ward=" + ward + ", street=" + street + ", houseNr=" + houseNr
                + ", gpslocation=" + gpslocation + "]";
    }


}
