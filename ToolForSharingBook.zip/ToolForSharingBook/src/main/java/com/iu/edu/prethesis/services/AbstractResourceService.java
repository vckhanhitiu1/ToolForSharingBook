package com.iu.edu.prethesis.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.function.Function;


/**
 * Created by Vo on 2/1/2017.
 */
public abstract class AbstractResourceService {

    final static Logger LOGGER = LoggerFactory.getLogger(AbstractResourceService.class);

    protected String bundleName;
    protected ResourceBundle resourceBundle;
    protected Map<String, ResourceBundle> resourceBundlesMap = new HashMap<String,ResourceBundle>();

    /**
     * @param languageLocale : a language locale
     * @return a resource bundle with name match with bundle name + language locale
     */
    protected ResourceBundle loadBundle(final Locale languageLocale) {
        String bundleNameWithLocale = bundleName + languageLocale.toString();
        return resourceBundlesMap
                .computeIfAbsent(bundleNameWithLocale, new Function<String, ResourceBundle>() {
                    @Override
                    public ResourceBundle apply(String k) {
                        return ResourceBundle.getBundle(bundleName, languageLocale);
                    }
                });
    }


    /**
     * @param key    : key word of a property in resource file
     * @param locale : language locale decide which language resource to get from.
     * @return a value string of key word in the language resource.
     */
    protected String get(String key, Locale locale) {

        String val = loadBundle(locale).getString(key);

        try {
            val = new String(val.getBytes("ISO-8859-1"), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            LOGGER.debug("Failed to encode message in this language! Using default encoding", e);
        }
        return val;
    }

}

