package com.iu.edu.prethesis.rest;

import com.iu.edu.prethesis.services.BookFacade;
import com.iu.edu.prethesis.services.MemberFacade;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

/**
 * Created by Vo on 3/6/2017.
 */
@Stateless
@Path("caches")
public class CacheResource{

    @EJB
    BookFacade bookFacade;

    @EJB
    MemberFacade memberFacade;

    @PUT
    public Response refreshCaches()
    {
        bookFacade.InitDataIntoCache();
        memberFacade.InitDataIntoCache();
        return Response.ok().build();
    }

    @PUT
    @Path("members")
    public Response refreshMemberCaches()
    {
        memberFacade.InitDataIntoCache();
        return Response.ok().build();
    }

    @PUT
    @Path("books")
    public Response refreshBookCaches()
    {
        bookFacade.InitDataIntoCache();
        return Response.ok().build();
    }


}
