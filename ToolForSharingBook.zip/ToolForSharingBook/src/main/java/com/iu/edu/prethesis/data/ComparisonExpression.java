package com.iu.edu.prethesis.data;

/**
 * Created by Vo on 2/2/2017.
 */
public enum ComparisonExpression{

    EQUAL("equal"),
    LIKE("like"),
    NOT_EQUAL("notequal"),
    GREATER_THAN("gt"),
    GREATER_THAN_OR_EQUAL("ge"),
    LESS_THAN("lt"),
    LESS_THAN_OR_EQUAL("le"),
    BETWEEN("between"),
    NOT_BETWEEN("notbetween");

    private String expression;

    ComparisonExpression(String expression) {
        this.expression = expression;
    }

    public String sqlExpression() {
        String value;
        if (this.compareTo(EQUAL) == 0) {
            value = "=";
        } else if (this.compareTo(LIKE) == 0) {
            value = "LIKE";
        } else if (this.compareTo(NOT_EQUAL) == 0) {
            value = "<>";
        } else if (this.compareTo(GREATER_THAN) == 0) {
            value = ">";
        } else if (this.compareTo(GREATER_THAN_OR_EQUAL) == 0) {
            value = ">=";
        } else if (this.compareTo(LESS_THAN) == 0) {
            value = "<";
        } else if (this.compareTo(LESS_THAN_OR_EQUAL) == 0) {
            value = "<=";
        } else if (this.compareTo(BETWEEN) == 0) {
            value = "BETWEEN";
        } else if (this.compareTo(NOT_BETWEEN) == 0) {
            value = "NOT BETWEEN";
        } else {
            throw new UnsupportedOperationException();
        }
        return value;
    }

}
