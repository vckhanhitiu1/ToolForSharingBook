package com.iu.edu.prethesis.data;

/**
 * Created by Vo on 2/3/2017.
 */


import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.IOException;
import java.io.Serializable;
import java.util.Objects;

/**
 * Search criteria defines  a search  pattern(field, value and expression) to
 * restrict the search result
 *
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SearchCriteria implements Serializable {

    private static final Logger log = LoggerFactory.getLogger(SearchCriteria.class);

    private String field = null;
    private Object value = null;
    private ComparisonExpression expression = null;

    public SearchCriteria() {
    }

    public SearchCriteria(String field, ComparisonExpression expression, Object value) {
        this.field = field;
        this.expression = expression;
        this.value = value;
    }

    public static SearchCriteria fromString(String json) throws IOException {
        if (json == null) {
            return null;
        }
        ObjectMapper mapper = new ObjectMapper();
        mapper.findAndRegisterModules();
        mapper.enable(DeserializationFeature.READ_ENUMS_USING_TO_STRING);
        return mapper.readValue(json, SearchCriteria.class);
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public ComparisonExpression getExpression() {
        return expression;
    }

    public void setExpression(ComparisonExpression expression) {
        this.expression = expression;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SearchCriteria)) return false;
        SearchCriteria that = (SearchCriteria) o;
        return Objects.equals(field, that.field) &&
                Objects.equals(value, that.value) &&
                expression == that.expression;
    }

    @Override
    public int hashCode() {
        return Objects.hash(field, value, expression);
    }

    @Override
    public String toString() {
        return String.format("EISearchCriteria{field:%s, expression:%s, value: %s}", field, expression, value);
    }


}
