package com.iu.edu.prethesis.data;

//import com.fasterxml.jackson.databind.ObjectMapper;

import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 * Created by Vo on 2/3/2017.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SortCriteria implements Serializable {

    private static final long serialVersionUID = 1L;
    private String field = null;
    private boolean descending = false;

    public SortCriteria() {
        // TODO Auto-generated constructor stub
    }

    /**
     * @param field
     */
    public SortCriteria(String field) {
        this.field = field;
    }

    /**
     * @param field
     * @param descending
     */
    public SortCriteria(String field, boolean descending) {
        this.field = field;
        this.descending = descending;
    }

    public static SortCriteria fromString(String json) throws IOException {
        if (json == null) {
            return null;
        }
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(json, SortCriteria.class);
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public boolean isDescending() {
        return descending;
    }

    public void setDescending(boolean descending) {
        this.descending = descending;
    }

    @Override
    public String toString() {
        return String.format("EIOrderCriteria{field:%s, descending:%s}", field, descending);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SortCriteria)) return false;
        SortCriteria that = (SortCriteria) o;
        return Objects.equals(field, that.field);
    }

    @Override
    public int hashCode() {
        return Objects.hash(field);
    }
}

