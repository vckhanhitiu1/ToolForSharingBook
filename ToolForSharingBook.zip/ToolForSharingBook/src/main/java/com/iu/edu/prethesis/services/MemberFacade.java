package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.data.RangeCriteria;
import com.iu.edu.prethesis.data.SearchByCriteria;
import com.iu.edu.prethesis.data.SortByCriteria;
import com.iu.edu.prethesis.data.bom.Member;
import com.iu.edu.prethesis.entity.MemberEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.function.Consumer;

/**
 * Created by Vo on 3/3/2017.
 */
@Stateless
public class MemberFacade{

    @EJB
    MemberService memberService;

    @EJB
    MemberCacheService memberCacheService;

    @EJB
    MessageService messageService;
    private static final Logger logger = LoggerFactory.getLogger(MemberFacade.class);

    public void save (Member member)
    {
        memberService.save(member);
        memberCacheService.put(member.getAccountCode(),member);
    }

    public Member readByCode(String code)
    {
        Member member = this.memberCacheService.get(code);
        if(member==null) {
            throw new EntityNotFoundException(messageService.get(MessageService.ErrorCode.MEMBER_NOT_EXIST));
        }
        return member;

    }

    public List<Member> search (SearchByCriteria searchBy, SortByCriteria orderBy , RangeCriteria range)
    {
        if(this.memberCacheService.values().isEmpty())
        {
            InitDataIntoCache();
        }
        return this.memberCacheService.search(searchBy,orderBy,range);
    }

    public void InitDataIntoCache() {

        List<MemberEntity> entities = this.memberService.findAll();
        this.memberCacheService.clearAll();
        entities.forEach(new Consumer<MemberEntity>(){
            @Override
            public void accept(MemberEntity entity) {
                MemberFacade.this.memberCacheService.put(entity.getAccountCode(), MemberFacade.this.memberService.toBom(entity));
            }
        });
        logger.info("+++initialize cache successfully!!!+++");
        logger.info("+++there're " + entities.size()+ " item(s) initialized in cache+++");
    }
}
