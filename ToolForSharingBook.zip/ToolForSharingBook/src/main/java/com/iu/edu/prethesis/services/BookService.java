package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.data.BookOrderField;
import com.iu.edu.prethesis.data.BookSearchField;
import com.iu.edu.prethesis.data.SearchByCriteria;
import com.iu.edu.prethesis.data.SearchCriteria;
import com.iu.edu.prethesis.data.bom.Book;
import com.iu.edu.prethesis.data.bom.BookType;
import com.iu.edu.prethesis.data.bom.Status;
import com.iu.edu.prethesis.data.ocr.OCRResponseError;
import com.iu.edu.prethesis.data.ocr.OCRResponseJSONBody;
import com.iu.edu.prethesis.entity.BookEntity;
import com.iu.edu.prethesis.entity.OwnBookEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityNotFoundException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Root;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.xml.ws.Response;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;


@Stateless
public class BookService extends GenericService<BookEntity, Book> {

    private static Logger logger = LoggerFactory.getLogger(BookService.class);

    private final static String SUBSCRIPTION_ID = "8d17516bfd4a43b49b8612f5fb932fa6";


    @EJB
    OwnBookService ownBookService;

    public BookService() {
        super(BookEntity.class);
    }

    public List <BookEntity> findAll() {
        TypedQuery <BookEntity> query = em.createNamedQuery(BookEntity.FIND_ALL, BookEntity.class);
        return query.getResultList();
    }

    public void save(@Valid Book book) {

        BookEntity previousBookEntity = this.findByIsbn(book.getIsbn());
        BookEntity currentBookEntity = this.toEntity(book);
            if (previousBookEntity != null && previousBookEntity.getIsbn().equals(currentBookEntity.getIsbn())) {
                this.save(previousBookEntity);
                book.setImage( "data:image/jpg;base64,"+BookEntity.changeFromByteTypeToStringType(previousBookEntity.getImage()));
            }

            else {
                this.save(currentBookEntity);
                book.setId(currentBookEntity.getId());

//               book.setImage("data:image/jpeg;base64," + BookEntity.changeFromByteTypeToStringType(currentBookEntity.getImage()));
            }

    }

    public void updateBookInfoByISBN(Book book)
    {
        BookEntity bookEntity=this.findByIsbn(book.getIsbn());
        if(bookEntity==null)
        {
            throw new EntityNotFoundException("The Book Does not exist");
        }
        bookEntity.setBookname(book.getBookname());
        bookEntity.setAuthors(book.getAuthors());
        bookEntity.setPrice(book.getPrice());
        bookEntity.setDescription(book.getDescription());
        bookEntity.setCopyright(book.getCopyright());
        bookEntity.setEdition(book.getEdition());
        bookEntity.setBooktype(book.getBooktype());
        bookEntity.setStatus(book.getStatus());
        this.save(bookEntity);
    }

//        if(book.getOwnerBook()!=null)
//        {
//            book.getOwnerBook().setBookId(book.getId());
//            ownerBookService.saveBelongToBookId(book.getOwnerBook());
//        }


//        if(book.getAuthors()!=null)
//        {
//            for(Authors authors: book.getAuthors())
//            {
//                authors.setBookId(book.getId());
//                authorService.save(authors);
//            }
//        }
//        book.setId(bookEntity.getId());
//        if(book.getBookOwners()!=null)
//        {
//            for(BookOwner bookOwner : book.getBookOwners())
//            {
//                bookOwner.setBookId(book.getId());
//                bookOwnerService.saveBelongToBookId(bookOwner);
//
//            }
//
//        }
//        if(book.getMembers()!=null)
//        {
//           for(Member member: book.getMembers())
//           {
//               if(book.getBookOwners()!=null) {
//                   for (BookOwner bookOwner : book.getBookOwners()) {
//
//                       member.setId(bookOwner.getMemberId());
//                       memberService.save(member);
//                   }
//               }
//           }
//        }
//
//
//        this.save(bookEntity);

//    }


    public boolean isSame(BookEntity previousBookEntity, BookEntity currentBookEntity) {
        return
                Objects.equals(previousBookEntity.getBookname(), currentBookEntity.getBookname()) &&
                        Objects.equals(previousBookEntity.getCopyright(), currentBookEntity.getCopyright()) &&
                        Objects.equals(previousBookEntity.getIsbn(), currentBookEntity.getIsbn());
    }


    public BookEntity findByIsbn(String isbn) {
        TypedQuery <BookEntity> query = em.createNamedQuery(BookEntity.FIND_BY_ISBN, BookEntity.class);
        query.setParameter("isbn", isbn);
        List <BookEntity> results = query.getResultList();
        if (results.isEmpty())
            return null;
        return results.get(0);
    }



    public BookEntity findByOwnBookId(Integer ownbookid) {
        TypedQuery <BookEntity> query = em.createNamedQuery(BookEntity.FIND_BY_OWN_BOOK_ID, BookEntity.class);
        query.setParameter("ownbookid", ownbookid);
        List <BookEntity> results = query.getResultList();
        if (results.isEmpty())
            return null;
        return results.get(0);
    }




    public BookEntity toEntity(Book bom) {
        if (bom == null) {
            return null;
        }
        BookEntity entity = new BookEntity();

        entity.setId(bom.getId());
        entity.setIsbn(bom.getIsbn());
        entity.setBookname(bom.getBookname());
        entity.setPrice(bom.getPrice());
        entity.setImage(BookEntity.decodeImage(bom.getImage()));
        entity.setDescription(bom.getDescription());
        entity.setCopyright(bom.getCopyright());
        entity.setEdition(bom.getEdition());
        entity.setBooktype(bom.getBooktype());
        entity.setStatus(bom.getStatus());
        entity.setAuthors(bom.getAuthors());
        entity.setOwnbookid(bom.getOwnbookid());
        return entity;
    }

    @Override
    public Book toBom(BookEntity entity) {
        if (entity == null) {
            return null;
        }
        Book bom = new Book();

        bom.setId(entity.getId());
        bom.setIsbn(entity.getIsbn());
        bom.setBookname(entity.getBookname());
        bom.setPrice(entity.getPrice());
        bom.setImage(BookEntity.encodeImage(entity.getImage()));
        bom.setDescription(entity.getDescription());
        bom.setCopyright(entity.getCopyright());
        bom.setEdition(entity.getEdition());
        bom.setBooktype(entity.getBooktype());
        bom.setStatus(entity.getStatus());
        bom.setAuthors(entity.getAuthors());
        bom.setOwnbookid(entity.getOwnbookid());
        return bom;
    }

}
