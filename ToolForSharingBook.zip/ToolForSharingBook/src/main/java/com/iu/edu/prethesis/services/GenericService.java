package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.entity.GenericEntity;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.List;

public abstract class GenericService<E extends GenericEntity, B> {
    private final Class<E> entityClass;

    @PersistenceContext(name = "thesisprojectPU")
    EntityManager em;


    public GenericService(Class<E> entityClass) {
        this.entityClass = entityClass;
    }

    public abstract E toEntity(B bom);

    public abstract B toBom(E entity);

    public EntityManager getEm() {
        return em;
    }

    public void setEm(EntityManager em) {
        this.em = em;
    }


    private boolean isUpdate(E entity)
    {
        return entity.getId()!=null;
    }

    public void save(E entity) {
        if (isUpdate(entity)) {
            this.em.merge(entity);
        } else {
            this.em.persist(entity);
        }
    }

    public E findById(Integer id) {
        return em.find(entityClass, id);
    }

    public void removeById(Integer id) {
        em.remove(findById(id));
    }



    public List<E> toEntities(List<B> boms) {
        if (boms == null) {
            return null;
        }
        List<E> entities = new ArrayList<E>();
        //Under testing
        for (B b : boms) {
            E entity = toEntity(b);
            if (entity != null)
                entities.add(entity);
        }

        return entities;
    }

    public List<B> toBoms(List<E> entities) {
        if (entities == null) {
            return null;
        }
        List<B> boms = new ArrayList<B>();
        //Under testing
        for (E e : entities) {
            B bom = toBom(e);
            if (bom != null)
                boms.add(bom);
        }

        return boms;
    }

}
