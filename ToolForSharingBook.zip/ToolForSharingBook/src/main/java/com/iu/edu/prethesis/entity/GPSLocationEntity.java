package com.iu.edu.prethesis.entity;

import com.iu.edu.prethesis.data.addrbom.GPSLocation;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

@SuppressWarnings("serial")
@Entity
@Table(name = "gps_location")
public class GPSLocationEntity extends GenericEntity implements Serializable {

    @Column(name = "latitude")
    private Float latitude;

    @Column(name="longtitude")
    private Float longtitude;


    public GPSLocationEntity(Float latitude, Float longtitude) {
        super();
        this.latitude = latitude;
        this.longtitude = longtitude;
    }


    public GPSLocationEntity() {

    }


    public Float getLatitude() {
        return latitude;
    }


    public void setLatitude(Float latitude) {
        this.latitude = latitude;
    }


    public Float getLongtitude() {
        return longtitude;
    }


    public void setLongtitude(Float longtitude) {
        this.longtitude = longtitude;
    }


    @Override
    public String toString() {
        return "GPSLocationEntity [latitude=" + latitude + ", longtitude=" + longtitude + "]";
    }


    public static GPSLocationEntity fromBom(GPSLocation bom)
    {
        if(bom==null)
        {
            return null;
        }
        GPSLocationEntity entity = new GPSLocationEntity();
        entity.setLatitude(bom.getLatitude());
        entity.setLongtitude(bom.getLatitude());
        return entity;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((latitude == null) ? 0 : latitude.hashCode());
        result = prime * result + ((longtitude == null) ? 0 : longtitude.hashCode());
        return result;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        GPSLocationEntity other = (GPSLocationEntity) obj;
        if (latitude == null) {
            if (other.latitude != null)
                return false;
        } else if (!latitude.equals(other.latitude))
            return false;
        if (longtitude == null) {
            if (other.longtitude != null)
                return false;
        } else if (!longtitude.equals(other.longtitude))
            return false;
        return true;
    }


}
