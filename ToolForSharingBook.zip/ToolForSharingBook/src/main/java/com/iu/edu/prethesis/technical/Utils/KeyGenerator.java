package com.iu.edu.prethesis.technical.Utils;

import java.security.Key;

/**
 * Created by Vo on 6/4/2017.
 */

public interface KeyGenerator {
    Key generateKey();
}
