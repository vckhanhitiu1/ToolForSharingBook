package com.iu.edu.prethesis.data.bom;

import com.iu.edu.prethesis.data.addrbom.Address;
import com.iu.edu.prethesis.technical.validation.EmailAddress;

import javax.persistence.Id;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Member implements Serializable {

    /*
     *
     */
    private Integer id;

    @NotNull
    @Size(max = 30, min = 1)
    private String name;
    /*
     *
     */
    @NotNull
    @Size(max = 20, min = 1)
    @Pattern(regexp="^(\\+\\d{1,2}\\s)?\\(?\\d{3}\\)?[\\s.-]\\d{3}[\\s.-]\\d{4}$",
            message="{invalid phonenumber}")
    private String phoneNr;


    /*
     *
     */
    @NotNull
    @Valid
    private Address address;
    /*
     *
     */
    @NotNull
//    @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\."
//            +"[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@"
//            +"(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?",
//            message="{invalid.email}")
    @EmailAddress
    private String emailAddress;


    @Pattern(regexp = "([^\\s]+(\\.(?i)(jpg|png|gif|bmp))$)", message = "{not an image}")
    private String image;
    /*
     *
     */
    @NotNull
    @Size(max=15, min = 1)
    private String accountCode;


    private OwnBooks ownBooks;


    public Member() {

    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {

        return id;
    }


    public Member(Integer id, String name, String phoneNr, Address address, String emailAddress, String image, String accountCode, OwnBooks ownBooks) {
        this.id = id;
        this.name = name;
        this.phoneNr = phoneNr;
        this.address = address;
        this.emailAddress = emailAddress;
        this.image = image;
        this.accountCode = accountCode;
        this.ownBooks = ownBooks;
    }

    public Member(Integer id, String name, String phoneNr, Address address, String emailAddress, String image, String accountCode) {
        this.id = id;
        this.name = name;
        this.phoneNr = phoneNr;
        this.address = address;
        this.emailAddress = emailAddress;
        this.image = image;
        this.accountCode = accountCode;
    }


    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public String getPhoneNr() {
        return phoneNr;
    }


    public void setPhoneNr(String phoneNr) {
        this.phoneNr = phoneNr;
    }


    public Address getAddress() {
        return address;
    }


    public void setAddress(Address address) {
        this.address = address;
    }


    public String getImage() {
        return image;
    }


    public void setImage(String image) {
        this.image = image;
    }


    public String getAccountCode() {
        return accountCode;
    }


    public void setAccountCode(String accountCode) {
        this.accountCode = accountCode;
    }

    public OwnBooks getOwnBooks() {
        return ownBooks;
    }

    public void setOwnBooks(OwnBooks ownBooks) {
        this.ownBooks = ownBooks;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Member member = (Member) o;

        if (id != null ? !id.equals(member.id) : member.id != null) return false;
        if (name != null ? !name.equals(member.name) : member.name != null) return false;
        if (phoneNr != null ? !phoneNr.equals(member.phoneNr) : member.phoneNr != null) return false;
        if (address != null ? !address.equals(member.address) : member.address != null) return false;
        if (emailAddress != null ? !emailAddress.equals(member.emailAddress) : member.emailAddress != null)
            return false;
        if (image != null ? !image.equals(member.image) : member.image != null) return false;
        return accountCode != null ? accountCode.equals(member.accountCode) : member.accountCode == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (phoneNr != null ? phoneNr.hashCode() : 0);
        result = 31 * result + (address != null ? address.hashCode() : 0);
        result = 31 * result + (emailAddress != null ? emailAddress.hashCode() : 0);
        result = 31 * result + (image != null ? image.hashCode() : 0);
        result = 31 * result + (accountCode != null ? accountCode.hashCode() : 0);
        return result;
    }
}
