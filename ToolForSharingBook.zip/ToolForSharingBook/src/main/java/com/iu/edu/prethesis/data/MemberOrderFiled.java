package com.iu.edu.prethesis.data;

/**
 * Created by Vo on 2/10/2017.
 */
public enum MemberOrderFiled {

    NAME("name"),

    LOCATION("location"),

    EMAIL("email");

    private String literal;

    MemberOrderFiled(String literal) {
        this.literal = literal;
    }

    public String getLiteral() {
        return literal;
    }

    public void setLiteral(String literal) {
        this.literal = literal;
    }
}
