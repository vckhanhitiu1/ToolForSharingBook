package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.data.authorsInfor.Authors;
import com.iu.edu.prethesis.entity.AuthorsEntity;

import javax.ejb.Stateless;
import javax.persistence.TypedQuery;
import javax.validation.Valid;
import java.util.List;
import java.util.Objects;

/**
 * Created by Vo on 3/22/2017.
 */
@Stateless
public class AuthorService  extends  GenericService<AuthorsEntity, Authors>{

    public AuthorService() {
        super(AuthorsEntity.class);
    }

    @Override
    public AuthorsEntity toEntity(Authors bom) {
        AuthorsEntity entity = new AuthorsEntity();
        entity.setFirstname(bom.getFirstname());
        entity.setLastname(bom.getLastname());
        return entity;
    }
    public List<AuthorsEntity> findAll() {
        TypedQuery<AuthorsEntity> query = em.createNamedQuery(AuthorsEntity.FIND_ALL,AuthorsEntity.class);
        return query.getResultList();
    }

    public void save(@Valid Authors authors)
    {
        AuthorsEntity previousAuthorEntity = this.findByBookId(authors.getBookId());
        AuthorsEntity currentAuthorEntity = this.toEntity(authors);
        if(previousAuthorEntity!=null && !this.isSame(previousAuthorEntity,currentAuthorEntity))
        {
            this.save(previousAuthorEntity);
        }
        this.save(currentAuthorEntity);
        authors.setId(currentAuthorEntity.getId());
    }

    public boolean isSame(AuthorsEntity previousAuthorEntity, AuthorsEntity currentAuthorEntity)
    {
        return Objects.equals(previousAuthorEntity.getBookId(), currentAuthorEntity.getBookId())&&
                Objects.equals(previousAuthorEntity.getFirstname(), currentAuthorEntity.getFirstname())&&
                Objects.equals(previousAuthorEntity.getLastname(),currentAuthorEntity.getLastname());
    }
    public AuthorsEntity findByBookId(Integer bookId)
    {
        TypedQuery<AuthorsEntity> query = em.createNamedQuery(AuthorsEntity.FIND_BY_BOOK_ID, AuthorsEntity.class);
        query.setParameter("bookId", bookId);
        List<AuthorsEntity> results = query.getResultList();
        if(results.isEmpty())
            return null;
        return  results.get(0);
    }

    @Override
    public Authors toBom(AuthorsEntity entity) {
        return null;
    }
}
