package com.iu.edu.prethesis.data.bom;

import javax.persistence.Id;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.List;

/**
 * Created by Vo on 5/7/2017.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class OwnerBook implements Serializable {

    @Id
    private Integer id;

    @Valid
    private List<Member> members;

    @NotNull
    private Integer bookId;

    public OwnerBook(Integer id, List <Member> members, Integer bookId) {
        this.id = id;
        this.members = members;
        this.bookId = bookId;
    }

    public OwnerBook() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List <Member> getMembers() {
        return members;
    }

    public void setMembers(List <Member> members) {
        this.members = members;
    }

    public Integer getBookId() {
        return bookId;
    }

    public void setBookId(Integer bookId) {
        this.bookId = bookId;
    }

    @Override
    public String toString() {
        return "OwnerBook{" +
                "id=" + id +
                ", members=" + members +
                ", bookId=" + bookId +
                '}';
    }
}
