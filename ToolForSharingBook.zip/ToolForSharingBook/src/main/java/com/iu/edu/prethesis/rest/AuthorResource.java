package com.iu.edu.prethesis.rest;

import com.iu.edu.prethesis.data.authorsInfor.Authors;
import com.iu.edu.prethesis.entity.AuthorsEntity;
import com.iu.edu.prethesis.services.AuthorService;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.net.URI;
import java.util.List;

/**
 * Created by Vo on 3/10/2017.
 */
@Stateless
@Path("/authors")
public class AuthorResource{

    @Context
    private UriInfo uriInfo;
    @PersistenceContext(name="thesisprojectPU")
    private EntityManager em;

    @EJB
    AuthorService authorsService;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createAuthors(Authors authors)
    {
        authorsService.save(authors);
        URI authorUri = uriInfo.getAbsolutePathBuilder().path(authors.getId().toString()).build();
        return Response .created(authorUri).build();

    }

    @GET
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    public List<AuthorsEntity> getAllMember()
    {
        return authorsService.findAll();
    }


}
