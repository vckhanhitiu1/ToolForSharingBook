package com.iu.edu.prethesis.data.authbom;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by Vo on 1/31/2017.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Role{


    private String name;

    private String displayname;

    public Role(String name, String displayname) {
        this.name = name;
        this.displayname = displayname;
    }

    public Role() {
    }

    public String getName() {
        return name;
    }

    public String getDisplayname() {
        return displayname;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDisplayname(String displayname) {
        this.displayname = displayname;
    }

    @Override
    public String toString() {
        return "Role{" +
                "name='" + name + '\'' +
                ", displayname='" + displayname + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Role role = (Role) o;

        if (name != null ? !name.equals(role.name) : role.name != null) return false;
        return displayname != null ? displayname.equals(role.displayname) : role.displayname == null;
    }

    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + (displayname != null ? displayname.hashCode() : 0);
        return result;
    }
}
