package com.iu.edu.prethesis.data.authbom;


import com.iu.edu.prethesis.technical.validation.EmailAddress;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Vo on 1/31/2017.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class LogInUser implements Serializable{


    private Integer id;

    /**
     * It's mandatory and unique in the system
     */
    @NotNull
    @Size(max = 20,min = 1)
    private String username;

    /**
     * It's mandatory and has at least 8 characters
     */
    @NotNull
    @Size(max = 30,min = 1)
    private String password;

    @NotNull
    @Size(max = 30, min = 1)
    private String passwordConfirm;

    @NotNull
    @EmailAddress
    private String email;
//    /**
//     * Indicate whether the user is blocked or not. if its value is true, the user wont be able to log into the system
//     */
//    private boolean blocked;

    /**
     * roles of the user
     */
    private String roles;


    public LogInUser() {
    }

    /**
     *
     * @param username
     * @param password
     */


    public LogInUser(Integer id, String username, String password, String roles) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.roles = roles;
    }

    public LogInUser(Integer id, String username, String password, String passwordConfirm, String roles) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.passwordConfirm = passwordConfirm;
        this.roles = roles;
    }

    public LogInUser(Integer id, String username, String password, String passwordConfirm, String email, String roles) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.passwordConfirm = passwordConfirm;
        this.email = email;
        this.roles = roles;
    }

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRoles() {
        return roles;
    }

    public void setRoles(String roles) {
        this.roles = roles;
    }

    public String getPasswordConfirm() {
        return passwordConfirm;
    }

    public void setPasswordConfirm(String passwordConfirm) {
        this.passwordConfirm = passwordConfirm;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
