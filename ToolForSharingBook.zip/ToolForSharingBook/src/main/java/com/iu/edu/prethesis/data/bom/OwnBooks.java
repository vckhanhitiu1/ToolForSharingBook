package com.iu.edu.prethesis.data.bom;


import javax.persistence.Id;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.List;

/**
 * Created by Vo on 5/7/2017.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class OwnBooks implements Serializable{

    @Id
    private Integer id;

    @Valid
    @NotNull
    private List<Book> books;

    @NotNull
    private Integer memberId;


    public OwnBooks(Integer id, List <Book> books, @NotNull Integer memberId) {
        this.id = id;
        this.books = books;
        this.memberId = memberId;
    }

    public OwnBooks() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List <Book> getBooks() {
        return books;
    }

    public void setBooks(List <Book> books) {
        this.books = books;
    }

    @NotNull
    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(@NotNull Integer memberId) {
        this.memberId = memberId;
    }


    @Override
    public String toString() {
        return "OwnBooks{" +
                "id=" + id +
                ", books=" + books +
                ", memberId=" + memberId +
                '}';
    }
}
